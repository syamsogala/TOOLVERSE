import {
  Cake,
  HeartPulse,
  Landmark,
  TrendingUp,
  ReceiptText,
  Percent,
  KeyRound,
  QrCode,
  type LucideIcon,
} from "lucide-react";

export type ToolCategory = "Health" | "Finance" | "Math" | "Utility";

export interface Tool {
  slug: string;
  name: string;
  description: string;
  category: ToolCategory;
  icon: LucideIcon;
  keywords: string[];
  available: boolean;
}

export const tools: Tool[] = [
  {
    slug: "age-calculator",
    name: "Age Calculator",
    description: "Know your exact age in years, months, days, hours and seconds.",
    category: "Utility",
    icon: Cake,
    keywords: ["age", "birthday", "date", "zodiac", "dob"],
    available: true,
  },
  {
    slug: "bmi-calculator",
    name: "BMI Calculator",
    description: "Check your body mass index and healthy weight range instantly.",
    category: "Health",
    icon: HeartPulse,
    keywords: ["bmi", "weight", "height", "health", "fitness"],
    available: true,
  },
  {
    slug: "emi-calculator",
    name: "EMI Calculator",
    description: "Plan loan repayments with monthly EMI, interest and totals.",
    category: "Finance",
    icon: Landmark,
    keywords: ["emi", "loan", "interest", "bank", "mortgage"],
    available: true,
  },
  {
    slug: "sip-calculator",
    name: "SIP Calculator",
    description: "Project mutual fund returns from your monthly investments.",
    category: "Finance",
    icon: TrendingUp,
    keywords: ["sip", "investment", "mutual fund", "returns"],
    available: true,
  },
  {
    slug: "gst-calculator",
    name: "GST Calculator",
    description: "Add or remove GST from any amount with a single tap.",
    category: "Finance",
    icon: ReceiptText,
    keywords: ["gst", "tax", "invoice", "billing"],
    available: true,
  },
  {
    slug: "percentage-calculator",
    name: "Percentage Calculator",
    description: "Solve every percentage problem: increase, decrease and share.",
    category: "Math",
    icon: Percent,
    keywords: ["percentage", "percent", "math", "ratio"],
    available: true,
  },
  {
    slug: "password-generator",
    name: "Password Generator",
    description: "Create strong, unguessable passwords in one click.",
    category: "Utility",
    icon: KeyRound,
    keywords: ["password", "security", "random", "generator"],
    available: true,
  },
  {
    slug: "qr-code-generator",
    name: "QR Code Generator",
    description: "Turn links and text into crisp, downloadable QR codes.",
    category: "Utility",
    icon: QrCode,
    keywords: ["qr", "code", "link", "scan", "generator"],
    available: true,
  },
];

export const categories: { name: ToolCategory; blurb: string }[] = [
  { name: "Finance", blurb: "Loans, taxes, investments and everyday money math." },
  { name: "Health", blurb: "Body metrics and wellness calculators that make sense." },
  { name: "Math", blurb: "Fast, accurate answers to everyday number problems." },
  { name: "Utility", blurb: "Generators and helpers you reach for every single day." },
];

export function searchTools(query: string): Tool[] {
  const q = query.trim().toLowerCase();
  if (!q) return tools;
  return tools.filter(
    (t) =>
      t.name.toLowerCase().includes(q) ||
      t.description.toLowerCase().includes(q) ||
      t.category.toLowerCase().includes(q) ||
      t.keywords.some((k) => k.includes(q)),
  );
}
