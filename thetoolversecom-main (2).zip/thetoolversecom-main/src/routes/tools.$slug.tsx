import type React from "react";
import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";
import { tools } from "@/data/tools";
import { AgeCalculator } from "@/components/tools/AgeCalculator";
import { BmiCalculator } from "@/components/tools/BmiCalculator";
import { EmiCalculator } from "@/components/tools/EmiCalculator";
import { SipCalculator } from "@/components/tools/SipCalculator";
import { GstCalculator } from "@/components/tools/GstCalculator";
import { PercentageCalculator } from "@/components/tools/PercentageCalculator";
import { PasswordGenerator } from "@/components/tools/PasswordGenerator";
import { QrCodeGenerator } from "@/components/tools/QrCodeGenerator";

const TOOL_COMPONENTS: Record<string, React.ComponentType> = {
  "age-calculator": AgeCalculator,
  "bmi-calculator": BmiCalculator,
  "emi-calculator": EmiCalculator,
  "sip-calculator": SipCalculator,
  "gst-calculator": GstCalculator,
  "percentage-calculator": PercentageCalculator,
  "password-generator": PasswordGenerator,
  "qr-code-generator": QrCodeGenerator,
};

export const Route = createFileRoute("/tools/$slug")({
  loader: ({ params }) => {
    const tool = tools.find((t) => t.slug === params.slug && t.available);
    if (!tool) throw notFound();
    return { name: tool.name, description: tool.description, slug: tool.slug };
  },
  head: ({ params, loaderData }) => {
    if (!loaderData) {
      return {
        meta: [{ title: "Tool unavailable — ToolVerse" }, { name: "robots", content: "noindex" }],
      };
    }
    const title = `${loaderData.name} — Free Online Tool | ToolVerse`;
    return {
      meta: [
        { title },
        { name: "description", content: loaderData.description },
        { property: "og:title", content: title },
        { property: "og:description", content: loaderData.description },
        { property: "og:type", content: "article" },
        { property: "og:url", content: `/tools/${params.slug}` },
        { name: "twitter:title", content: title },
        { name: "twitter:description", content: loaderData.description },
      ],
      links: [{ rel: "canonical", href: `/tools/${params.slug}` }],
      scripts: [
        {
          type: "application/ld+json",
          children: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "WebApplication",
            name: loaderData.name,
            description: loaderData.description,
            applicationCategory: "UtilitiesApplication",
            offers: { "@type": "Offer", price: "0", priceCurrency: "USD" },
          }),
        },
      ],
    };
  },
  component: ToolPage,
});

function ToolPage() {
  const { name, description, slug } = Route.useLoaderData();
  const Body = TOOL_COMPONENTS[slug];

  return (
    <section className="mx-auto max-w-7xl px-5 py-12 lg:px-8 lg:py-16">
      <Link
        to="/tools"
        className="inline-flex items-center gap-2 text-sm text-muted-foreground transition-colors hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" /> All tools
      </Link>
      <h1 className="mt-6 font-display text-4xl font-bold sm:text-5xl">
        {name.split(" ")[0]} <span className="gradient-text">{name.split(" ").slice(1).join(" ")}</span>
      </h1>
      <p className="mt-4 max-w-2xl text-muted-foreground">{description}</p>

      <div className="mt-12">{Body ? <Body /> : null}</div>
    </section>
  );
}
