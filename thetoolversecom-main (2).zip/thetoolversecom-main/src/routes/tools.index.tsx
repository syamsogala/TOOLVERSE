import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import { categories, searchTools } from "@/data/tools";
import { ToolCard } from "@/components/site/ToolCard";
import { Reveal } from "@/components/site/Reveal";

export const Route = createFileRoute("/tools/")({
  head: () => ({
    meta: [
      { title: "All Tools — ToolVerse" },
      {
        name: "description",
        content:
          "Browse every free ToolVerse utility: age, BMI, EMI, SIP, GST and percentage calculators plus password and QR code generators.",
      },
      { property: "og:title", content: "All Tools — ToolVerse" },
      { property: "og:description", content: "Browse every free tool on ToolVerse." },
      { property: "og:url", content: "/tools" },
    ],
    links: [{ rel: "canonical", href: "/tools" }],
  }),
  component: ToolsPage,
});

function ToolsPage() {
  const [query, setQuery] = useState("");
  const [cat, setCat] = useState<string>("All");

  const results = useMemo(() => {
    const base = searchTools(query);
    return cat === "All" ? base : base.filter((t) => t.category === cat);
  }, [query, cat]);

  return (
    <section className="mx-auto max-w-7xl px-5 py-14 lg:px-8 lg:py-20">
      <div className="max-w-2xl animate-rise">
        <h1 className="font-display text-4xl font-bold sm:text-5xl">
          The <span className="gradient-text">ToolVerse</span> collection
        </h1>
        <p className="mt-4 text-muted-foreground">
          Search instantly across every tool. Results filter as you type.
        </p>
      </div>

      <div className="glass mt-8 flex items-center gap-3 rounded-2xl p-2 pl-5">
        <Search className="h-5 w-5 shrink-0 text-muted-foreground" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          type="search"
          aria-label="Search tools"
          placeholder="Search over 100+ online tools..."
          className="min-w-0 flex-1 bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground"
        />
      </div>

      <div className="mt-6 flex flex-wrap gap-2">
        {["All", ...categories.map((c) => c.name)].map((c) => (
          <button
            key={c}
            onClick={() => setCat(c)}
            className={`rounded-full px-4 py-2 text-sm font-medium transition-all ${
              cat === c
                ? "gradient-brand text-primary-foreground"
                : "glass text-muted-foreground hover:text-foreground"
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      {results.length === 0 ? (
        <p className="glass mt-10 rounded-2xl p-10 text-center text-muted-foreground">
          No tools matched your search. Try “calculator” or “generator”.
        </p>
      ) : (
        <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {results.map((tool, i) => (
            <Reveal key={tool.slug} delay={i * 50}>
              <ToolCard tool={tool} />
            </Reveal>
          ))}
        </div>
      )}
    </section>
  );
}
