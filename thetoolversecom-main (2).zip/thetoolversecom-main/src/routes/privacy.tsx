import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy — ToolVerse" },
      {
        name: "description",
        content:
          "ToolVerse runs every calculation in your browser. Read how we handle data, cookies and analytics.",
      },
      { property: "og:title", content: "Privacy Policy — ToolVerse" },
      { property: "og:description", content: "How ToolVerse handles your data." },
      { property: "og:url", content: "/privacy" },
    ],
    links: [{ rel: "canonical", href: "/privacy" }],
  }),
  component: Privacy,
});

function Privacy() {
  return (
    <section className="mx-auto max-w-3xl px-5 py-14 lg:px-8 lg:py-20">
      <h1 className="font-display text-4xl font-bold">Privacy Policy</h1>
      <div className="glass mt-8 space-y-6 rounded-3xl p-8 text-sm leading-relaxed text-muted-foreground">
        <p>
          <strong className="text-foreground">Local by design.</strong> Every ToolVerse tool runs
          entirely in your browser. Dates, amounts and text you enter are never transmitted to a
          server or stored by us.
        </p>
        <p>
          <strong className="text-foreground">Cookies.</strong> We store a single local preference
          for your light or dark theme. No advertising or tracking cookies are used.
        </p>
        <p>
          <strong className="text-foreground">Third parties.</strong> Fonts are loaded from Google
          Fonts. We do not sell, rent or share any personal information, because we do not collect
          it.
        </p>
        <p>
          <strong className="text-foreground">Contact.</strong> Questions about privacy? Reach us at
          hello@toolverse.app.
        </p>
      </div>
    </section>
  );
}
