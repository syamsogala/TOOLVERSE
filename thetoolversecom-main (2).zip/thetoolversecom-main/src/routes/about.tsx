import { createFileRoute } from "@tanstack/react-router";
import { Rocket, Lock, Feather } from "lucide-react";
import { Reveal } from "@/components/site/Reveal";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About ToolVerse — One Place. Infinite Tools." },
      {
        name: "description",
        content:
          "ToolVerse exists to make everyday online tools fast, free and genuinely beautiful. Learn about the product and the principles behind it.",
      },
      { property: "og:title", content: "About ToolVerse" },
      { property: "og:description", content: "Why we built a beautiful home for online tools." },
      { property: "og:url", content: "/about" },
    ],
    links: [{ rel: "canonical", href: "/about" }],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <section className="mx-auto max-w-4xl px-5 py-14 lg:px-8 lg:py-20">
      <h1 className="font-display text-4xl font-bold sm:text-5xl">
        About <span className="gradient-text">ToolVerse</span>
      </h1>
      <p className="mt-6 text-lg leading-relaxed text-muted-foreground">
        Most online tools work — they just feel like relics. Cluttered layouts, aggressive ads and
        forms that fight you. ToolVerse is the opposite: a single, calm, fast home for the utilities
        you actually use, designed with the care usually reserved for paid software.
      </p>

      <div className="mt-12 grid gap-5 sm:grid-cols-3">
        {[
          { Icon: Rocket, t: "Instantly fast", d: "Everything runs in your browser, no waiting." },
          { Icon: Lock, t: "Privacy first", d: "Your inputs never leave your device." },
          { Icon: Feather, t: "Beautifully simple", d: "One design system across every tool." },
        ].map(({ Icon, t, d }, i) => (
          <Reveal key={t} delay={i * 80}>
            <div className="glass hover-lift h-full rounded-3xl p-6">
              <span className="grid h-12 w-12 place-items-center rounded-2xl gradient-brand text-primary-foreground">
                <Icon className="h-6 w-6" />
              </span>
              <h2 className="mt-4 text-lg font-semibold">{t}</h2>
              <p className="mt-2 text-sm text-muted-foreground">{d}</p>
            </div>
          </Reveal>
        ))}
      </div>

      <div className="glass mt-12 rounded-3xl p-8">
        <h2 className="font-display text-2xl font-semibold">Where we're going</h2>
        <p className="mt-3 text-muted-foreground">
          Version 2.0 is built on a scalable architecture: a shared design system, a single tool
          registry and reusable result components. That means ToolVerse can grow past 100 tools
          without a single redesign.
        </p>
      </div>
    </section>
  );
}
