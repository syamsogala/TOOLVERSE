import { createFileRoute, Link } from "@tanstack/react-router";
import { categories, tools } from "@/data/tools";
import { Reveal } from "@/components/site/Reveal";

export const Route = createFileRoute("/categories")({
  head: () => ({
    meta: [
      { title: "Tool Categories — ToolVerse" },
      {
        name: "description",
        content:
          "Explore ToolVerse categories: finance, health, math and everyday utility tools, all free and beautifully designed.",
      },
      { property: "og:title", content: "Tool Categories — ToolVerse" },
      { property: "og:description", content: "Finance, health, math and utility tools." },
      { property: "og:url", content: "/categories" },
    ],
    links: [{ rel: "canonical", href: "/categories" }],
  }),
  component: CategoriesPage,
});

function CategoriesPage() {
  return (
    <section className="mx-auto max-w-7xl px-5 py-14 lg:px-8 lg:py-20">
      <h1 className="font-display text-4xl font-bold sm:text-5xl">
        Browse by <span className="gradient-text">category</span>
      </h1>
      <p className="mt-4 max-w-xl text-muted-foreground">
        Every tool is organised so you always land on the right one in seconds.
      </p>

      <div className="mt-12 grid gap-6 lg:grid-cols-2">
        {categories.map((c, i) => {
          const items = tools.filter((t) => t.category === c.name);
          return (
            <Reveal key={c.name} delay={i * 70}>
              <div className="glass hover-lift h-full rounded-3xl p-7">
                <div className="flex items-baseline justify-between gap-4">
                  <h2 className="font-display text-2xl font-semibold">{c.name}</h2>
                  <span className="text-xs text-muted-foreground">{items.length} tools</span>
                </div>
                <p className="mt-2 text-sm text-muted-foreground">{c.blurb}</p>
                <ul className="mt-5 space-y-2">
                  {items.map((t) => (
                    <li key={t.slug}>
                      {t.available ? (
                        <Link
                          to="/tools/$slug"
                          params={{ slug: t.slug }}
                          className="text-sm font-medium text-foreground underline-offset-4 hover:underline"
                        >
                          {t.name}
                        </Link>
                      ) : (
                        <span className="text-sm text-muted-foreground">{t.name} · soon</span>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            </Reveal>
          );
        })}
      </div>
    </section>
  );
}
