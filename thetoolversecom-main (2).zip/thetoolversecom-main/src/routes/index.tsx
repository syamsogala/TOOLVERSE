import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  Search,
  ArrowRight,
  Sparkles,
  Zap,
  ShieldCheck,
  Infinity as InfinityIcon,
  Gauge,
  Lock,
  Wand2,
  Layers,
} from "lucide-react";
import heroImg from "@/assets/hero-tools.png";
import { searchTools, tools } from "@/data/tools";
import { ToolCard } from "@/components/site/ToolCard";
import { Reveal } from "@/components/site/Reveal";
import { Counter } from "@/components/site/Counter";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ToolVerse — Free Online Tools Made Beautiful" },
      {
        name: "description",
        content:
          "One place. Infinite tools. Use 100+ fast, free and beautifully designed online calculators and generators — no sign-up required.",
      },
      { property: "og:title", content: "ToolVerse — Free Online Tools Made Beautiful" },
      {
        property: "og:description",
        content: "One Place. Infinite Tools. Fast. Simple. Free forever.",
      },
      { property: "og:url", content: "/" },
      { name: "twitter:title", content: "ToolVerse — Free Online Tools Made Beautiful" },
      { name: "twitter:description", content: "One Place. Infinite Tools. Free forever." },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: Home,
});

const FEATURES = [
  {
    Icon: Gauge,
    title: "Instant by design",
    body: "Every tool renders and computes in the browser — no round-trips, no spinners, no waiting.",
  },
  {
    Icon: Lock,
    title: "Private by default",
    body: "Your numbers never leave your device. Nothing is stored, tracked or uploaded anywhere.",
  },
  {
    Icon: Wand2,
    title: "Crafted, not generated",
    body: "One design system, obsessive spacing and motion tuned to feel effortless on any screen.",
  },
  {
    Icon: Layers,
    title: "Built to scale",
    body: "A shared toolkit means new tools ship in hours while staying pixel-consistent.",
  },
];

function Home() {
  const [query, setQuery] = useState("");
  const navigate = useNavigate();
  const results = useMemo(() => searchTools(query), [query]);
  const marquee = useMemo(() => [...tools, ...tools], []);

  return (
    <>
      {/* ---------------- HERO ---------------- */}
      <section className="mx-auto max-w-7xl px-5 pb-12 pt-12 lg:px-8 lg:pb-28 lg:pt-24">
        <div className="grid items-center gap-14 lg:grid-cols-[1.05fr_0.95fr]">
          <div className="animate-rise">
            <span className="glass-strong inline-flex items-center gap-2.5 rounded-full px-4 py-1.5 text-xs font-medium text-muted-foreground">
              <span className="relative grid h-2 w-2 place-items-center">
                <span className="absolute h-2 w-2 rounded-full bg-accent animate-pulse-ring" />
                <span className="h-2 w-2 rounded-full bg-accent" />
              </span>
              Version 2.0 — built to scale to 100+ tools
            </span>

            <h1 className="mt-7 font-display text-[2.6rem] font-bold leading-[1.05] text-balance-tight sm:text-6xl lg:text-[4.25rem]">
              Free Online Tools
              <br />
              <span className="gradient-text-animated">Made Beautiful.</span>
            </h1>

            <p className="mt-6 max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg">
              One Place. Infinite Tools. Calculators, generators and converters that load instantly,
              run privately in your browser, and look like they belong in a design portfolio.
            </p>

            <div className="glass-strong ring-gradient mt-9 flex items-center gap-3 rounded-2xl p-2 pl-5 transition-shadow duration-300 focus-within:shadow-[var(--shadow-glow)]">
              <Search className="h-5 w-5 shrink-0 text-muted-foreground" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                type="search"
                aria-label="Search tools"
                placeholder="Search over 100+ online tools..."
                className="min-w-0 flex-1 bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground"
              />
              <button
                onClick={() => navigate({ to: "/tools" })}
                className="hover-press hidden shrink-0 rounded-xl gradient-brand px-5 py-3 text-sm font-semibold text-primary-foreground sm:block"
              >
                Search
              </button>
            </div>

            {query && (
              <div className="glass-strong mt-3 max-h-72 animate-rise overflow-auto rounded-2xl p-2">
                {results.length === 0 && (
                  <p className="px-4 py-3 text-sm text-muted-foreground">
                    No tools matched “{query}”.
                  </p>
                )}
                {results.map((t) => (
                  <Link
                    key={t.slug}
                    to={t.available ? "/tools/$slug" : "/tools"}
                    params={{ slug: t.slug }}
                    className="flex items-center justify-between gap-3 rounded-xl px-4 py-3 text-sm transition-colors hover:bg-surface"
                  >
                    <span className="min-w-0 truncate font-medium">{t.name}</span>
                    <span className="shrink-0 text-xs text-muted-foreground">{t.category}</span>
                  </Link>
                ))}
              </div>
            )}

            <div className="mt-9 flex flex-wrap gap-3">
              <Link
                to="/tools"
                className="hover-press group inline-flex items-center gap-2 rounded-xl gradient-brand px-6 py-3.5 text-sm font-semibold text-primary-foreground"
              >
                Explore Tools
                <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
              </Link>
              <a
                href="#popular"
                className="glass-strong hover-press inline-flex items-center gap-2 rounded-xl px-6 py-3.5 text-sm font-semibold"
              >
                Popular Tools
              </a>
            </div>

            <dl className="mt-12 grid grid-cols-3 gap-3 sm:gap-4">
              {[
                { v: 100, suffix: "+", label: "Tools", Icon: InfinityIcon },
                { v: 24, suffix: "/7", label: "Available", Icon: Zap },
                { v: 100, suffix: "%", label: "Free", Icon: ShieldCheck },
              ].map(({ v, suffix, label, Icon }) => (
                <div
                  key={label}
                  className="glass-strong hover-lift rounded-2xl p-4 text-center sm:p-5"
                >
                  <Icon className="mx-auto h-4 w-4 text-accent" />
                  <dd className="mt-2 font-display text-2xl font-bold tracking-[-0.02em] sm:text-3xl">
                    <Counter value={v} />
                    {suffix}
                  </dd>
                  <dt className="mt-1 text-xs text-muted-foreground sm:text-sm">{label}</dt>
                </div>
              ))}
            </dl>
          </div>

          <div className="relative">
            <div
              className="absolute inset-10 rounded-full bg-secondary/30 blur-[100px]"
              aria-hidden
            />
            <div
              className="absolute inset-x-10 bottom-6 h-24 rounded-full bg-primary/25 blur-[70px]"
              aria-hidden
            />
            <img
              src={heroImg}
              alt="ToolVerse dashboard illustration with calculators, QR code and security tools"
              width={1024}
              height={1024}
              fetchPriority="high"
              className="relative mx-auto w-full max-w-lg animate-float drop-shadow-2xl"
            />
          </div>
        </div>
      </section>

      {/* ---------------- MARQUEE ---------------- */}
      <section aria-hidden className="relative overflow-hidden py-4">
        <div className="hairline" />
        <div className="mt-6 flex w-full overflow-hidden [mask-image:linear-gradient(90deg,transparent,#000_12%,#000_88%,transparent)]">
          <div className="flex w-max animate-marquee gap-3 pr-3">
            {marquee.map((t, i) => (
              <span
                key={`${t.slug}-${i}`}
                className="glass inline-flex shrink-0 items-center gap-2 rounded-full px-4 py-2 text-xs font-medium text-muted-foreground"
              >
                <t.icon className="h-3.5 w-3.5 text-accent" strokeWidth={1.8} />
                {t.name}
              </span>
            ))}
          </div>
        </div>
        <div className="mt-6 hairline" />
      </section>

      {/* ---------------- POPULAR ---------------- */}
      <section id="popular" className="mx-auto max-w-7xl scroll-mt-24 px-5 py-16 lg:px-8 lg:py-28">
        <Reveal>
          <div className="max-w-2xl">
            <span className="text-xs font-semibold uppercase tracking-[0.28em] text-accent">
              Popular tools
            </span>
            <h2 className="mt-4 font-display text-3xl font-bold text-balance-tight sm:text-5xl">
              Everything you need, <span className="gradient-text">nothing you don’t.</span>
            </h2>
            <p className="mt-5 text-base leading-relaxed text-muted-foreground">
              Handcrafted tools with instant results, thoughtful design and zero distractions.
            </p>
          </div>
        </Reveal>

        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {tools.map((tool, i) => (
            <Reveal key={tool.slug} delay={i * 60}>
              <ToolCard tool={tool} />
            </Reveal>
          ))}
        </div>
      </section>

      {/* ---------------- WHY ---------------- */}
      <section className="mx-auto max-w-7xl px-5 py-4 lg:px-8 lg:py-12">
        <div className="grid gap-12 lg:grid-cols-[0.85fr_1.15fr]">
          <Reveal>
            <div className="lg:sticky lg:top-28">
              <span className="text-xs font-semibold uppercase tracking-[0.28em] text-accent">
                Why ToolVerse
              </span>
              <h2 className="mt-4 font-display text-3xl font-bold text-balance-tight sm:text-4xl">
                Designed like a product, <span className="gradient-text">not a utility page.</span>
              </h2>
              <p className="mt-5 max-w-md text-muted-foreground">
                No ads shoved between inputs. No forms that reload. Just fast, focused tools with a
                consistent, considered interface.
              </p>
              <Link
                to="/about"
                className="mt-7 inline-flex items-center gap-2 text-sm font-semibold text-foreground"
              >
                Read our story{" "}
                <ArrowRight className="h-4 w-4 text-accent transition-transform duration-300 hover:translate-x-1" />
              </Link>
            </div>
          </Reveal>

          <div className="grid gap-5 sm:grid-cols-2">
            {FEATURES.map((f, i) => (
              <Reveal key={f.title} delay={i * 80}>
                <div className="glass-strong ring-gradient hover-lift h-full rounded-[1.75rem] p-7">
                  <span className="grid h-12 w-12 place-items-center rounded-2xl bg-surface text-accent ring-1 ring-glass-border">
                    <f.Icon className="h-5.5 w-5.5" strokeWidth={1.7} />
                  </span>
                  <h3 className="mt-5 font-display text-lg font-semibold">{f.title}</h3>
                  <p className="mt-2.5 text-sm leading-relaxed text-muted-foreground">{f.body}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ---------------- CTA ---------------- */}
      <section className="mx-auto max-w-7xl px-5 pb-10 pt-16 lg:px-8 lg:pt-24">
        <Reveal>
          <div className="glass-strong ring-gradient relative overflow-hidden rounded-[2rem] p-10 text-center sm:p-16">
            <div className="absolute inset-0 bg-[var(--gradient-soft)]" aria-hidden />
            <div
              className="absolute -top-24 left-1/2 h-64 w-[38rem] -translate-x-1/2 rounded-full bg-primary/30 blur-[110px]"
              aria-hidden
            />
            <span className="glass relative inline-flex items-center gap-2 rounded-full px-4 py-1.5 text-xs text-muted-foreground">
              <Sparkles className="h-3.5 w-3.5 text-accent" /> Free forever — no sign-up
            </span>
            <h2 className="relative mt-6 font-display text-3xl font-bold text-balance-tight sm:text-5xl">
              Built to grow into <span className="gradient-text">infinite tools.</span>
            </h2>
            <p className="relative mx-auto mt-5 max-w-xl text-muted-foreground">
              Every ToolVerse utility shares one design system, so new tools ship in hours — not
              weeks.
            </p>
            <Link
              to="/tools"
              className="hover-press group relative mt-9 inline-flex items-center gap-2 rounded-xl gradient-brand px-7 py-4 text-sm font-semibold text-primary-foreground"
            >
              Browse the collection
              <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
            </Link>
          </div>
        </Reveal>
      </section>
    </>
  );
}
