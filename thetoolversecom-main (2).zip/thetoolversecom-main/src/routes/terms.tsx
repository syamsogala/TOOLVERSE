import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: "Terms of Use — ToolVerse" },
      {
        name: "description",
        content:
          "The simple terms for using ToolVerse's free online tools, including accuracy and liability notes.",
      },
      { property: "og:title", content: "Terms of Use — ToolVerse" },
      { property: "og:description", content: "The terms for using ToolVerse tools." },
      { property: "og:url", content: "/terms" },
    ],
    links: [{ rel: "canonical", href: "/terms" }],
  }),
  component: Terms,
});

function Terms() {
  return (
    <section className="mx-auto max-w-3xl px-5 py-14 lg:px-8 lg:py-20">
      <h1 className="font-display text-4xl font-bold">Terms of Use</h1>
      <div className="glass mt-8 space-y-6 rounded-3xl p-8 text-sm leading-relaxed text-muted-foreground">
        <p>
          <strong className="text-foreground">Free to use.</strong> ToolVerse is provided free of
          charge for personal and commercial use, with no account required.
        </p>
        <p>
          <strong className="text-foreground">Accuracy.</strong> Our tools are carefully built and
          tested, but results are provided for general guidance. Always verify important financial,
          medical or legal decisions with a qualified professional.
        </p>
        <p>
          <strong className="text-foreground">Availability.</strong> We aim for 24/7 uptime but may
          update or retire tools at any time.
        </p>
        <p>
          <strong className="text-foreground">Liability.</strong> ToolVerse is not liable for any
          loss arising from the use of results produced by its tools.
        </p>
      </div>
    </section>
  );
}
