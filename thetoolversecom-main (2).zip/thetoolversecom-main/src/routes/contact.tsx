import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Mail, MessageSquare, Send } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact ToolVerse — Requests & Feedback" },
      {
        name: "description",
        content:
          "Suggest a new tool, report a bug or say hello. The ToolVerse team reads every message.",
      },
      { property: "og:title", content: "Contact ToolVerse" },
      { property: "og:description", content: "Suggest a tool or send feedback to ToolVerse." },
      { property: "og:url", content: "/contact" },
    ],
    links: [{ rel: "canonical", href: "/contact" }],
  }),
  component: ContactPage,
});

function ContactPage() {
  const [sent, setSent] = useState(false);

  return (
    <section className="mx-auto max-w-5xl px-5 py-14 lg:px-8 lg:py-20">
      <div className="grid gap-10 lg:grid-cols-[0.9fr_1.1fr]">
        <div>
          <h1 className="font-display text-4xl font-bold sm:text-5xl">
            Let's <span className="gradient-text">talk</span>
          </h1>
          <p className="mt-4 text-muted-foreground">
            Missing a tool you need every day? Tell us and it might ship next week.
          </p>
          <div className="mt-8 space-y-3">
            <div className="glass flex items-center gap-3 rounded-2xl p-4">
              <Mail className="h-5 w-5 shrink-0 text-accent" />
              <span className="min-w-0 truncate text-sm">hello@toolverse.app</span>
            </div>
            <div className="glass flex items-center gap-3 rounded-2xl p-4">
              <MessageSquare className="h-5 w-5 shrink-0 text-accent" />
              <span className="min-w-0 truncate text-sm">Replies within 24 hours</span>
            </div>
          </div>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            setSent(true);
            toast.success("Message sent — thanks for reaching out!");
          }}
          className="glass rounded-3xl p-7"
        >
          <div className="grid gap-4">
            <Field label="Name" id="name" placeholder="Ada Lovelace" />
            <Field label="Email" id="email" type="email" placeholder="you@example.com" />
            <div>
              <label htmlFor="message" className="text-sm font-medium">
                Message
              </label>
              <textarea
                id="message"
                required
                rows={5}
                placeholder="Which tool should we build next?"
                className="mt-2 w-full rounded-xl border border-glass-border bg-surface px-4 py-3 text-sm outline-none transition-shadow placeholder:text-muted-foreground focus:ring-2 focus:ring-ring"
              />
            </div>
            <button
              type="submit"
              className="inline-flex items-center justify-center gap-2 rounded-xl gradient-brand px-6 py-3.5 text-sm font-semibold text-primary-foreground transition-transform hover:scale-[1.02]"
            >
              {sent ? "Sent" : "Send message"} <Send className="h-4 w-4" />
            </button>
          </div>
        </form>
      </div>
    </section>
  );
}

function Field({
  label,
  id,
  type = "text",
  placeholder,
}: {
  label: string;
  id: string;
  type?: string;
  placeholder: string;
}) {
  return (
    <div>
      <label htmlFor={id} className="text-sm font-medium">
        {label}
      </label>
      <input
        id={id}
        type={type}
        required
        placeholder={placeholder}
        className="mt-2 w-full rounded-xl border border-glass-border bg-surface px-4 py-3 text-sm outline-none transition-shadow placeholder:text-muted-foreground focus:ring-2 focus:ring-ring"
      />
    </div>
  );
}
