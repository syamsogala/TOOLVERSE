import { useState } from "react";
import { ReceiptText } from "lucide-react";
import {
  BigCard,
  Confetti,
  Fact,
  Field,
  Panel,
  PrimaryButton,
  ResultHeader,
  ShareActions,
  Stat,
  inputClass,
} from "./kit";

const RATES = [0, 3, 5, 12, 18, 28];

interface GstResult {
  base: number;
  gst: number;
  total: number;
  rate: number;
  cgst: number;
  mode: "add" | "remove";
}

export function GstCalculator() {
  const [mode, setMode] = useState<"add" | "remove">("add");
  const [amount, setAmount] = useState("10000");
  const [rate, setRate] = useState(18);
  const [result, setResult] = useState<GstResult | null>(null);
  const [confetti, setConfetti] = useState(false);

  const calculate = () => {
    const a = parseFloat(amount);
    if (!a || a < 0) return;
    let base: number;
    let total: number;
    if (mode === "add") {
      base = a;
      total = a * (1 + rate / 100);
    } else {
      total = a;
      base = a / (1 + rate / 100);
    }
    const gst = total - base;
    setResult({ base, gst, total, rate, cgst: gst / 2, mode });
    setConfetti(true);
    window.setTimeout(() => setConfetti(false), 4200);
  };

  return (
    <>
      {confetti && <Confetti />}
      <div className="grid gap-8 lg:grid-cols-[1fr_0.9fr]">
        <Panel title="Amount and tax slab">
          <div className="glass inline-flex rounded-2xl p-1">
            {(["add", "remove"] as const).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`rounded-xl px-5 py-2 text-sm font-medium transition-all ${
                  mode === m ? "gradient-brand text-primary-foreground" : "text-muted-foreground"
                }`}
              >
                {m === "add" ? "Add GST" : "Remove GST"}
              </button>
            ))}
          </div>
          <Field
            label={mode === "add" ? "Amount excluding GST (₹)" : "Amount including GST (₹)"}
            htmlFor="gst-a"
          >
            <input
              id="gst-a"
              type="number"
              inputMode="decimal"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className={inputClass}
            />
          </Field>
          <Field label="GST rate">
            <div className="flex flex-wrap gap-2">
              {RATES.map((r) => (
                <button
                  key={r}
                  onClick={() => setRate(r)}
                  className={`rounded-xl border border-glass-border px-4 py-2.5 text-sm font-medium transition-all hover:scale-105 ${
                    rate === r ? "gradient-brand text-primary-foreground" : "bg-surface"
                  }`}
                >
                  {r}%
                </button>
              ))}
            </div>
          </Field>
          <PrimaryButton onClick={calculate} Icon={ReceiptText}>
            Calculate GST
          </PrimaryButton>
        </Panel>

        <div className="glass rounded-3xl p-7">
          <h3 className="font-display text-lg font-semibold">GST slabs at a glance</h3>
          <ul className="mt-5 space-y-3 text-sm">
            {[
              ["0%", "Fresh produce, milk, books"],
              ["3%", "Gold, silver, jewellery"],
              ["5%", "Essentials, transport, small restaurants"],
              ["12%", "Processed food, business-class travel"],
              ["18%", "Most goods, software and services"],
              ["28%", "Luxury goods, tobacco, premium autos"],
            ].map(([slab, use]) => (
              <li
                key={slab}
                className="flex items-center justify-between rounded-xl border border-glass-border px-4 py-3"
              >
                <span className="font-semibold">{slab}</span>
                <span className="text-right text-muted-foreground">{use}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {result && (
        <div className="mt-14">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <ResultHeader>
              Your <span className="gradient-text">tax breakdown</span>
            </ResultHeader>
            <ShareActions
              title="GST breakdown — ToolVerse"
              text={`Base ₹${Math.round(result.base).toLocaleString()} + ${result.rate}% GST ₹${Math.round(result.gst).toLocaleString()} = ₹${Math.round(result.total).toLocaleString()} (ToolVerse).`}
            />
          </div>

          <div className="mt-6 grid gap-4 sm:grid-cols-3">
            <BigCard label="Total GST" value={result.gst} decimals={2} prefix="₹" />
            <Stat label="Base amount" value={result.base} decimals={2} prefix="₹" />
            <Stat label="Total payable" value={result.total} decimals={2} prefix="₹" />
          </div>

          <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Stat label="CGST (half)" value={result.cgst} decimals={2} prefix="₹" />
            <Stat label="SGST (half)" value={result.cgst} decimals={2} prefix="₹" />
            <Stat label="IGST (inter-state)" value={result.gst} decimals={2} prefix="₹" />
            <Fact label="Applied rate" value={`${result.rate}%`} />
          </div>

          <div className="glass mt-4 rounded-3xl p-6">
            <p className="text-sm text-muted-foreground">Invoice summary</p>
            <table className="mt-4 w-full text-left text-sm">
              <tbody>
                <tr className="border-b border-glass-border">
                  <td className="py-3">Taxable value</td>
                  <td className="py-3 text-right font-semibold">
                    ₹{result.base.toFixed(2)}
                  </td>
                </tr>
                <tr className="border-b border-glass-border">
                  <td className="py-3">CGST @ {(result.rate / 2).toFixed(1)}%</td>
                  <td className="py-3 text-right font-semibold">₹{result.cgst.toFixed(2)}</td>
                </tr>
                <tr className="border-b border-glass-border">
                  <td className="py-3">SGST @ {(result.rate / 2).toFixed(1)}%</td>
                  <td className="py-3 text-right font-semibold">₹{result.cgst.toFixed(2)}</td>
                </tr>
                <tr>
                  <td className="py-3 font-semibold">Invoice total</td>
                  <td className="py-3 text-right font-display text-lg font-bold">
                    ₹{result.total.toFixed(2)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}
    </>
  );
}
