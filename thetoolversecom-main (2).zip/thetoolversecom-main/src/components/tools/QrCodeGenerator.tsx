import { useEffect, useState } from "react";
import QRCode from "qrcode";
import { Download, QrCode as QrIcon } from "lucide-react";
import { toast } from "sonner";
import { Action, Confetti, Field, Panel, PrimaryButton, ResultHeader, inputClass } from "./kit";

const SIZES = [256, 512, 1024];

export function QrCodeGenerator() {
  const [text, setText] = useState("https://toolverse.app");
  const [size, setSize] = useState(512);
  const [dark, setDark] = useState("#0B1220");
  const [light, setLight] = useState("#FFFFFF");
  const [margin, setMargin] = useState(2);
  const [dataUrl, setDataUrl] = useState("");
  const [confetti, setConfetti] = useState(false);

  useEffect(() => {
    let cancelled = false;
    const value = text.trim() || " ";
    QRCode.toDataURL(value, {
      width: size,
      margin,
      errorCorrectionLevel: "H",
      color: { dark, light },
    })
      .then((url) => {
        if (!cancelled) setDataUrl(url);
      })
      .catch(() => {
        if (!cancelled) setDataUrl("");
      });
    return () => {
      cancelled = true;
    };
  }, [text, size, dark, light, margin]);

  const download = (ext: "png" | "svg") => {
    if (ext === "png") {
      if (!dataUrl) return;
      const a = document.createElement("a");
      a.href = dataUrl;
      a.download = "toolverse-qr.png";
      a.click();
      toast.success("QR code downloaded");
      return;
    }
    QRCode.toString(text.trim() || " ", {
      type: "svg",
      margin,
      errorCorrectionLevel: "H",
      color: { dark, light },
    }).then((svg) => {
      const blob = new Blob([svg], { type: "image/svg+xml" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = "toolverse-qr.svg";
      a.click();
      URL.revokeObjectURL(a.href);
      toast.success("SVG downloaded");
    });
  };

  const celebrate = () => {
    setConfetti(true);
    window.setTimeout(() => setConfetti(false), 4200);
    download("png");
  };

  return (
    <>
      {confetti && <Confetti />}
      <div className="grid gap-8 lg:grid-cols-[1fr_0.9fr]">
        <Panel title="What should the QR code contain?">
          <Field label="Link or text" hint="URLs, Wi-Fi details, UPI IDs, notes — anything." htmlFor="qr-t">
            <textarea
              id="qr-t"
              rows={3}
              value={text}
              onChange={(e) => setText(e.target.value)}
              className={`${inputClass} resize-y`}
            />
          </Field>
          <Field label="Resolution">
            <div className="flex flex-wrap gap-2">
              {SIZES.map((s) => (
                <button
                  key={s}
                  onClick={() => setSize(s)}
                  className={`rounded-xl border border-glass-border px-4 py-2.5 text-sm font-medium transition-all hover:scale-105 ${
                    size === s ? "gradient-brand text-primary-foreground" : "bg-surface"
                  }`}
                >
                  {s}px
                </button>
              ))}
            </div>
          </Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Foreground" htmlFor="qr-d">
              <input
                id="qr-d"
                type="color"
                value={dark}
                onChange={(e) => setDark(e.target.value)}
                className="h-12 w-full cursor-pointer rounded-2xl border border-glass-border bg-surface p-1"
              />
            </Field>
            <Field label="Background" htmlFor="qr-l">
              <input
                id="qr-l"
                type="color"
                value={light}
                onChange={(e) => setLight(e.target.value)}
                className="h-12 w-full cursor-pointer rounded-2xl border border-glass-border bg-surface p-1"
              />
            </Field>
          </div>
          <Field label={`Quiet zone — ${margin} modules`} htmlFor="qr-m">
            <input
              id="qr-m"
              type="range"
              min="0"
              max="8"
              value={margin}
              onChange={(e) => setMargin(Number(e.target.value))}
              className="w-full accent-[var(--primary)]"
            />
          </Field>
          <PrimaryButton onClick={celebrate} Icon={QrIcon}>
            Download PNG
          </PrimaryButton>
        </Panel>

        <div className="glass animate-rise flex flex-col items-center justify-center rounded-3xl p-8">
          <div className="relative">
            <div className="absolute inset-6 rounded-full bg-primary/25 blur-[70px]" aria-hidden />
            {dataUrl ? (
              <img
                src={dataUrl}
                alt="Generated QR code preview"
                width={320}
                height={320}
                className="relative w-full max-w-xs rounded-2xl"
              />
            ) : (
              <div className="relative flex h-72 w-72 items-center justify-center rounded-2xl border border-glass-border text-sm text-muted-foreground">
                Enter some text to preview
              </div>
            )}
          </div>
          <p className="mt-6 text-center text-xs text-muted-foreground">
            High error-correction (level H) — scannable even when partly covered.
          </p>
          <div className="mt-5 flex flex-wrap justify-center gap-2 print:hidden">
            <Action onClick={() => download("png")} Icon={Download} label="PNG" />
            <Action onClick={() => download("svg")} Icon={Download} label="SVG" />
          </div>
        </div>
      </div>

      <div className="mt-14">
        <ResultHeader>
          Ideas for your <span className="gradient-text">QR codes</span>
        </ResultHeader>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {[
            ["Website link", "https://example.com"],
            ["Email", "mailto:hello@example.com"],
            ["Phone call", "tel:+919876543210"],
            ["Wi-Fi", "WIFI:T:WPA;S:MyNetwork;P:password;;"],
          ].map(([label, value]) => (
            <button
              key={label}
              onClick={() => setText(value ?? "")}
              className="glass hover-lift rounded-2xl p-5 text-left"
            >
              <p className="font-display text-lg font-semibold">{label}</p>
              <p className="mt-1 truncate text-xs text-muted-foreground">{value}</p>
            </button>
          ))}
        </div>
      </div>
    </>
  );
}
