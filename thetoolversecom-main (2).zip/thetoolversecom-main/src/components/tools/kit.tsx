import { useEffect, useMemo, useState, type ReactNode } from "react";
import { Copy, Download, Printer, Share2, Sparkles, type LucideIcon } from "lucide-react";
import { toast } from "sonner";

export function AnimatedNumber({
  value,
  decimals = 0,
  prefix = "",
  suffix = "",
}: {
  value: number;
  decimals?: number | undefined;
  prefix?: string | undefined;
  suffix?: string | undefined;
}) {
  const [n, setN] = useState(0);
  useEffect(() => {
    let raf = 0;
    const start = performance.now();
    const from = 0;
    const tick = (now: number) => {
      const p = Math.min((now - start) / 900, 1);
      setN(from + (value - from) * (1 - Math.pow(1 - p, 3)));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value]);
  return (
    <>
      {prefix}
      {n.toLocaleString(undefined, {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals,
      })}
      {suffix}
    </>
  );
}

export function Confetti() {
  const pieces = useMemo(
    () =>
      Array.from({ length: 60 }, (_, i) => ({
        id: i,
        left: Math.random() * 100,
        delay: Math.random() * 0.8,
        duration: 2.4 + Math.random() * 1.6,
        size: 6 + Math.random() * 8,
        hue: ["var(--primary)", "var(--secondary)", "var(--accent)"][i % 3],
      })),
    [],
  );
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 z-50 overflow-hidden">
      {pieces.map((p) => (
        <span
          key={p.id}
          style={{
            left: `${p.left}%`,
            width: p.size,
            height: p.size * 0.5,
            background: p.hue,
            animation: `confetti-fall ${p.duration}s linear ${p.delay}s forwards`,
          }}
          className="absolute top-0 rounded-[2px]"
        />
      ))}
    </div>
  );
}

export function Panel({
  title,
  badge = "Instant, private, in-browser",
  children,
}: {
  title: string;
  badge?: string;
  children: ReactNode;
}) {
  return (
    <div className="glass-strong ring-gradient animate-rise rounded-[1.75rem] p-7 sm:p-9">
      <span className="inline-flex items-center gap-2 rounded-full border border-glass-border px-3 py-1 text-xs text-muted-foreground">
        <Sparkles className="h-3.5 w-3.5 text-accent" /> {badge}
      </span>
      <h2 className="mt-5 font-display text-2xl font-semibold">{title}</h2>
      <div className="mt-6 space-y-5">{children}</div>
    </div>
  );
}

export function Field({
  label,
  hint,
  children,
  htmlFor,
}: {
  label: string;
  hint?: string;
  children: ReactNode;
  htmlFor?: string;
}) {
  return (
    <div>
      <label htmlFor={htmlFor} className="block text-sm font-medium">
        {label}
      </label>
      <div className="mt-2">{children}</div>
      {hint && <p className="mt-1.5 text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}

export const inputClass =
  "w-full rounded-2xl border border-glass-border bg-surface px-5 py-4 text-base outline-none transition-shadow focus:ring-2 focus:ring-ring";

export function PrimaryButton({
  children,
  onClick,
  Icon,
  type = "button",
}: {
  children: ReactNode;
  onClick?: () => void;
  Icon?: LucideIcon;
  type?: "button" | "submit";
}) {
  return (
    <button
      type={type}
      onClick={onClick}
      className="group hover-press sheen w-full rounded-2xl gradient-brand px-6 py-4 text-sm font-semibold text-primary-foreground"
    >
      <span className="inline-flex items-center gap-2">
        {Icon && <Icon className="h-4 w-4 transition-transform group-hover:rotate-12" />}
        {children}
      </span>
    </button>
  );
}

export function Action({
  onClick,
  Icon,
  label,
}: {
  onClick: () => void;
  Icon: LucideIcon;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      className="glass-strong hover-press inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium"
    >
      <Icon className="h-4 w-4" /> {label}
    </button>
  );
}

export function ShareActions({ title, text }: { title: string; text: string }) {
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success("Copied to clipboard");
    } catch {
      toast.error("Could not copy");
    }
  };
  const share = async () => {
    if (typeof navigator !== "undefined" && navigator.share) {
      try {
        await navigator.share({ title, text });
        return;
      } catch {
        /* user cancelled */
      }
    }
    await copy();
  };
  return (
    <div className="flex flex-wrap gap-2 print:hidden">
      <Action onClick={share} Icon={Share2} label="Share" />
      <Action onClick={copy} Icon={Copy} label="Copy" />
      <Action onClick={() => window.print()} Icon={Download} label="Save as PDF" />
      <Action onClick={() => window.print()} Icon={Printer} label="Print" />
    </div>
  );
}

export function BigCard({
  label,
  value,
  decimals = 0,
  prefix,
  suffix,
}: {
  label: string;
  value: number;
  decimals?: number | undefined;
  prefix?: string | undefined;
  suffix?: string | undefined;
}) {
  return (
    <div className="hover-lift sheen relative overflow-hidden rounded-[1.75rem] p-7 text-primary-foreground gradient-brand">
      <p className="font-display text-4xl font-bold sm:text-5xl">
        <AnimatedNumber value={value} decimals={decimals} prefix={prefix} suffix={suffix} />
      </p>
      <p className="mt-1 text-sm opacity-85">{label}</p>
    </div>
  );
}

export function Stat({
  label,
  value,
  decimals = 0,
  prefix,
  suffix,
}: {
  label: string;
  value: number;
  decimals?: number | undefined;
  prefix?: string | undefined;
  suffix?: string | undefined;
}) {
  return (
    <div className="glass-strong hover-lift rounded-2xl p-5">
      <p className="font-display text-2xl font-bold">
        <AnimatedNumber value={value} decimals={decimals} prefix={prefix} suffix={suffix} />
      </p>
      <p className="mt-1 text-xs text-muted-foreground">{label}</p>
    </div>
  );
}

export function Fact({ label, value }: { label: string; value: string }) {
  return (
    <div className="glass-strong hover-lift rounded-2xl p-5">
      <p className="font-display text-xl font-semibold">{value}</p>
      <p className="mt-1 text-xs text-muted-foreground">{label}</p>
    </div>
  );
}

export function Bar({
  label,
  value,
  caption,
}: {
  label: string;
  value: number;
  caption?: string;
}) {
  return (
    <div className="glass-strong rounded-[1.5rem] p-6">
      <p className="text-sm text-muted-foreground">{label}</p>
      <p className="mt-2 font-display text-2xl font-bold">{caption ?? `${value.toFixed(1)}%`}</p>
      <div className="mt-4 h-2.5 w-full overflow-hidden rounded-full bg-surface">
        <div
          className="h-full rounded-full gradient-brand transition-[width] duration-1000 ease-out"
          style={{ width: `${Math.min(Math.max(value, 0), 100)}%` }}
        />
      </div>
    </div>
  );
}

export function ResultHeader({ children }: { children: ReactNode }) {
  return <h2 className="font-display text-2xl font-bold sm:text-3xl">{children}</h2>;
}

export function Donut({
  segments,
}: {
  segments: { label: string; value: number; color: string }[];
}) {
  const total = segments.reduce((s, x) => s + x.value, 0) || 1;
  let acc = 0;
  const stops = segments
    .map((s) => {
      const from = (acc / total) * 100;
      acc += s.value;
      const to = (acc / total) * 100;
      return `${s.color} ${from}% ${to}%`;
    })
    .join(", ");
  return (
    <div className="glass-strong rounded-[1.5rem] p-6">
      <div className="flex items-center gap-6">
        <div
          className="relative h-32 w-32 shrink-0 rounded-full transition-all duration-700"
          style={{ background: `conic-gradient(${stops})` }}
        >
          <div className="absolute inset-[22%] rounded-full bg-background" />
        </div>
        <ul className="space-y-3 text-sm">
          {segments.map((s) => (
            <li key={s.label} className="flex items-center gap-2">
              <span
                className="h-3 w-3 rounded-full"
                style={{ background: s.color }}
                aria-hidden
              />
              <span className="text-muted-foreground">{s.label}</span>
              <span className="font-semibold">
                {((s.value / total) * 100).toFixed(1)}%
              </span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export function formatCurrency(n: number, currency = "INR") {
  return n.toLocaleString(undefined, {
    style: "currency",
    currency,
    maximumFractionDigits: 0,
  });
}
