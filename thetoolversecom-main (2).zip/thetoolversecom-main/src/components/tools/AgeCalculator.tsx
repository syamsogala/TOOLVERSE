import { useEffect, useMemo, useRef, useState } from "react";
import {
  CalendarHeart,
  Copy,
  Download,
  Printer,
  Share2,
  Sparkles,
  PartyPopper,
} from "lucide-react";
import { toast } from "sonner";
import cakeImg from "@/assets/age-illustration.png";

interface AgeResult {
  years: number;
  months: number;
  days: number;
  totalDays: number;
  totalWeeks: number;
  totalMonths: number;
  totalHours: number;
  totalMinutes: number;
  totalSeconds: number;
  bornDay: string;
  zodiac: string;
  chineseZodiac: string;
  leapYear: boolean;
  nextBirthdayDays: number;
  nextBirthdayHours: number;
  birthdayProgress: number;
  lifeProgress: number;
  birthDate: string;
}

const ZODIAC: [string, number, number][] = [
  ["Capricorn", 1, 19],
  ["Aquarius", 2, 18],
  ["Pisces", 3, 20],
  ["Aries", 4, 19],
  ["Taurus", 5, 20],
  ["Gemini", 6, 20],
  ["Cancer", 7, 22],
  ["Leo", 8, 22],
  ["Virgo", 9, 22],
  ["Libra", 10, 22],
  ["Scorpio", 11, 21],
  ["Sagittarius", 12, 21],
  ["Capricorn", 12, 31],
];

const CHINESE = [
  "Monkey",
  "Rooster",
  "Dog",
  "Pig",
  "Rat",
  "Ox",
  "Tiger",
  "Rabbit",
  "Dragon",
  "Snake",
  "Horse",
  "Goat",
];

function zodiacFor(d: Date) {
  const m = d.getMonth() + 1;
  const day = d.getDate();
  for (const [name, zm, zd] of ZODIAC) {
    if (m < zm || (m === zm && day <= zd)) return name;
  }
  return "Capricorn";
}

function isLeap(y: number) {
  return (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0;
}

function computeAge(birth: Date, now = new Date()): AgeResult {
  let years = now.getFullYear() - birth.getFullYear();
  let months = now.getMonth() - birth.getMonth();
  let days = now.getDate() - birth.getDate();
  if (days < 0) {
    months -= 1;
    days += new Date(now.getFullYear(), now.getMonth(), 0).getDate();
  }
  if (months < 0) {
    years -= 1;
    months += 12;
  }

  const ms = now.getTime() - birth.getTime();
  const totalSeconds = Math.floor(ms / 1000);
  const totalDays = Math.floor(ms / 86_400_000);

  let next = new Date(now.getFullYear(), birth.getMonth(), birth.getDate());
  if (next.getTime() < now.getTime()) next = new Date(now.getFullYear() + 1, birth.getMonth(), birth.getDate());
  const untilMs = next.getTime() - now.getTime();
  const prev = new Date(next.getFullYear() - 1, birth.getMonth(), birth.getDate());
  const cycle = next.getTime() - prev.getTime();

  return {
    years,
    months,
    days,
    totalDays,
    totalWeeks: Math.floor(totalDays / 7),
    totalMonths: years * 12 + months,
    totalHours: Math.floor(ms / 3_600_000),
    totalMinutes: Math.floor(ms / 60_000),
    totalSeconds,
    bornDay: birth.toLocaleDateString(undefined, { weekday: "long" }),
    zodiac: zodiacFor(birth),
    chineseZodiac: CHINESE[birth.getFullYear() % 12] ?? "—",
    leapYear: isLeap(birth.getFullYear()),
    nextBirthdayDays: Math.floor(untilMs / 86_400_000),
    nextBirthdayHours: Math.floor((untilMs % 86_400_000) / 3_600_000),
    birthdayProgress: Math.min(100, ((cycle - untilMs) / cycle) * 100),
    lifeProgress: Math.min(100, (years / 80) * 100),
    birthDate: birth.toLocaleDateString(undefined, { dateStyle: "long" }),
  };
}

function AnimatedNumber({ value }: { value: number }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    let raf = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const p = Math.min((now - start) / 900, 1);
      setN(Math.round(value * (1 - Math.pow(1 - p, 3))));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value]);
  return <>{n.toLocaleString()}</>;
}

function Confetti() {
  const pieces = useMemo(
    () =>
      Array.from({ length: 60 }, (_, i) => ({
        id: i,
        left: Math.random() * 100,
        delay: Math.random() * 0.8,
        duration: 2.4 + Math.random() * 1.6,
        size: 6 + Math.random() * 8,
        hue: ["var(--primary)", "var(--secondary)", "var(--accent)"][i % 3],
      })),
    [],
  );
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 z-50 overflow-hidden">
      {pieces.map((p) => (
        <span
          key={p.id}
          style={{
            left: `${p.left}%`,
            width: p.size,
            height: p.size * 0.5,
            background: p.hue,
            animation: `confetti-fall ${p.duration}s linear ${p.delay}s forwards`,
          }}
          className="absolute top-0 rounded-[2px]"
        />
      ))}
    </div>
  );
}

export function AgeCalculator() {
  const [date, setDate] = useState("");
  const [result, setResult] = useState<AgeResult | null>(null);
  const [live, setLive] = useState(false);
  const [confetti, setConfetti] = useState(false);
  const resultRef = useRef<HTMLDivElement>(null);

  // live-ticking seconds
  useEffect(() => {
    if (!live || !date) return;
    const id = setInterval(() => setResult(computeAge(new Date(date))), 1000);
    return () => clearInterval(id);
  }, [live, date]);


  const calculate = () => {
    if (!date) {
      toast.error("Pick your date of birth first.");
      return;
    }
    const birth = new Date(date);
    if (birth.getTime() > Date.now()) {
      toast.error("Date of birth cannot be in the future.");
      return;
    }
    setResult(computeAge(birth));
    setLive(true);
    setConfetti(true);
    setTimeout(() => setConfetti(false), 4200);
    setTimeout(() => resultRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 120);
  };

  const summary = result
    ? [
        `ToolVerse Age Calculator`,
        `Date of birth: ${result.birthDate} (${result.bornDay})`,
        `Age: ${result.years} years, ${result.months} months, ${result.days} days`,
        `Total days: ${result.totalDays.toLocaleString()}`,
        `Total weeks: ${result.totalWeeks.toLocaleString()}`,
        `Total hours: ${result.totalHours.toLocaleString()}`,
        `Zodiac: ${result.zodiac} · Chinese zodiac: ${result.chineseZodiac}`,
        `Next birthday in ${result.nextBirthdayDays} days`,
      ].join("\n")
    : "";

  const copy = async () => {
    await navigator.clipboard.writeText(summary);
    toast.success("Result copied to clipboard");
  };

  const share = async () => {
    if (navigator.share) {
      try {
        await navigator.share({ title: "My age — ToolVerse", text: summary });
      } catch {
        /* dismissed */
      }
    } else {
      await copy();
    }
  };

  return (
    <>
      {confetti && <Confetti />}

      <div className="grid items-center gap-10 lg:grid-cols-[1fr_0.85fr]">
        <div className="glass animate-rise rounded-3xl p-7 sm:p-9">
          <span className="inline-flex items-center gap-2 rounded-full border border-glass-border px-3 py-1 text-xs text-muted-foreground">
            <Sparkles className="h-3.5 w-3.5 text-accent" /> Instant, private, in-browser
          </span>
          <h2 className="mt-5 font-display text-2xl font-semibold">Enter your date of birth</h2>
          <label htmlFor="dob" className="mt-6 block text-sm font-medium">
            Date of birth
          </label>
          <input
            id="dob"
            type="date"
            value={date}
            max={new Date().toISOString().slice(0, 10)}
            onChange={(e) => setDate(e.target.value)}
            className="mt-2 w-full rounded-2xl border border-glass-border bg-surface px-5 py-4 text-base outline-none transition-shadow focus:ring-2 focus:ring-ring"
          />
          <button
            onClick={calculate}
            className="group mt-6 w-full overflow-hidden rounded-2xl gradient-brand px-6 py-4 text-sm font-semibold text-primary-foreground transition-transform duration-300 hover:scale-[1.02] active:scale-[0.99]"
          >
            <span className="inline-flex items-center gap-2">
              <CalendarHeart className="h-4 w-4 transition-transform group-hover:rotate-12" />
              Calculate my age
            </span>
          </button>
          <p className="mt-4 text-xs text-muted-foreground">
            Nothing is uploaded — the entire calculation happens on your device.
          </p>
        </div>

        <div className="relative">
          <div className="absolute inset-10 rounded-full bg-primary/25 blur-[80px]" aria-hidden />
          <img
            src={cakeImg}
            alt="Birthday cake illustration"
            width={816}
            height={816}
            loading="lazy"
            className="relative mx-auto w-full max-w-sm animate-float"
          />
        </div>
      </div>

      {result && (
        <div ref={resultRef} id="age-result" className="mt-16 scroll-mt-24">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <h2 className="font-display text-2xl font-bold sm:text-3xl">
              Your <span className="gradient-text">age dashboard</span>
            </h2>
            <div className="flex flex-wrap gap-2 print:hidden">
              <Action onClick={share} Icon={Share2} label="Share" />
              <Action onClick={copy} Icon={Copy} label="Copy" />
              <Action onClick={() => window.print()} Icon={Download} label="Save as PDF" />
              <Action onClick={() => window.print()} Icon={Printer} label="Print" />
            </div>
          </div>

          <div className="mt-6 grid gap-4 sm:grid-cols-3">
            <BigCard label="Years" value={result.years} />
            <BigCard label="Months" value={result.months} />
            <BigCard label="Days" value={result.days} />
          </div>

          <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Stat label="Total days" value={result.totalDays} />
            <Stat label="Total weeks" value={result.totalWeeks} />
            <Stat label="Total months" value={result.totalMonths} />
            <Stat label="Total hours" value={result.totalHours} />
            <Stat label="Total minutes" value={result.totalMinutes} />
            <Stat label="Total seconds" value={result.totalSeconds} />
            <Stat label="Age in weeks" value={result.totalWeeks} />
            <Stat label="Age in months" value={result.totalMonths} />
          </div>

          <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Fact label="Born on" value={result.bornDay} />
            <Fact label="Zodiac sign" value={result.zodiac} />
            <Fact label="Chinese zodiac" value={result.chineseZodiac} />
            <Fact label="Leap birth year" value={result.leapYear ? "Yes" : "No"} />
          </div>

          <div className="mt-4 grid gap-4 lg:grid-cols-3">
            <div className="glass rounded-3xl p-6">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <PartyPopper className="h-4 w-4 text-accent" /> Next birthday
              </div>
              <p className="mt-3 font-display text-3xl font-bold">
                {result.nextBirthdayDays}
                <span className="text-base font-medium text-muted-foreground"> days</span>{" "}
                {result.nextBirthdayHours}
                <span className="text-base font-medium text-muted-foreground"> hrs</span>
              </p>
            </div>
            <Bar label="Birthday progress" value={result.birthdayProgress} />
            <Bar label="Life progress (of 80 years)" value={result.lifeProgress} />
          </div>
        </div>
      )}
    </>
  );
}

function Action({
  onClick,
  Icon,
  label,
}: {
  onClick: () => void;
  Icon: typeof Copy;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      className="glass inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium transition-transform hover:scale-[1.04]"
    >
      <Icon className="h-4 w-4" /> {label}
    </button>
  );
}

function BigCard({ label, value }: { label: string; value: number }) {
  return (
    <div className="hover-lift relative overflow-hidden rounded-3xl p-7 text-primary-foreground gradient-brand">
      <p className="font-display text-5xl font-bold">
        <AnimatedNumber value={value} />
      </p>
      <p className="mt-1 text-sm opacity-85">{label}</p>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return (
    <div className="glass hover-lift rounded-2xl p-5">
      <p className="font-display text-2xl font-bold">
        <AnimatedNumber value={value} />
      </p>
      <p className="mt-1 text-xs text-muted-foreground">{label}</p>
    </div>
  );
}

function Fact({ label, value }: { label: string; value: string }) {
  return (
    <div className="glass hover-lift rounded-2xl p-5">
      <p className="font-display text-xl font-semibold">{value}</p>
      <p className="mt-1 text-xs text-muted-foreground">{label}</p>
    </div>
  );
}

function Bar({ label, value }: { label: string; value: number }) {
  return (
    <div className="glass rounded-3xl p-6">
      <p className="text-sm text-muted-foreground">{label}</p>
      <p className="mt-2 font-display text-2xl font-bold">{value.toFixed(1)}%</p>
      <div className="mt-4 h-2.5 w-full overflow-hidden rounded-full bg-surface">
        <div
          className="h-full rounded-full gradient-brand transition-[width] duration-1000 ease-out"
          style={{ width: `${value}%` }}
        />
      </div>
    </div>
  );
}
