import { useCallback, useEffect, useState } from "react";
import { Copy, KeyRound, RefreshCw, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { Action, Confetti, Field, Panel, PrimaryButton, ResultHeader, Stat } from "./kit";

const SETS = {
  lower: "abcdefghijkmnopqrstuvwxyz",
  upper: "ABCDEFGHJKLMNPQRSTUVWXYZ",
  numbers: "23456789",
  symbols: "!@#$%^&*()-_=+[]{};:,.?/",
  ambiguous: "il1Lo0O",
};

interface Options {
  length: number;
  lower: boolean;
  upper: boolean;
  numbers: boolean;
  symbols: boolean;
  avoidAmbiguous: boolean;
}

function randomInt(max: number) {
  const arr = new Uint32Array(1);
  crypto.getRandomValues(arr);
  return (arr[0] ?? 0) % max;
}

function generate(o: Options) {
  let pool = "";
  if (o.lower) pool += SETS.lower;
  if (o.upper) pool += SETS.upper;
  if (o.numbers) pool += SETS.numbers;
  if (o.symbols) pool += SETS.symbols;
  if (!o.avoidAmbiguous) pool += SETS.ambiguous;
  if (!pool) pool = SETS.lower;
  let out = "";
  for (let i = 0; i < o.length; i++) out += pool[randomInt(pool.length)];
  return out;
}

function strengthOf(pw: string, o: Options) {
  let variety = 0;
  if (/[a-z]/.test(pw)) variety += 26;
  if (/[A-Z]/.test(pw)) variety += 26;
  if (/[0-9]/.test(pw)) variety += 10;
  if (/[^a-zA-Z0-9]/.test(pw)) variety += 24;
  const entropy = pw.length * Math.log2(Math.max(variety, 2));
  const label =
    entropy < 40 ? "Weak" : entropy < 60 ? "Fair" : entropy < 90 ? "Strong" : "Fortress";
  const guesses = Math.pow(2, entropy);
  const seconds = guesses / 1e10;
  void o;
  return { entropy, label, seconds };
}

function humanTime(s: number) {
  if (s < 60) return `${s.toFixed(0)} seconds`;
  if (s < 3600) return `${(s / 60).toFixed(0)} minutes`;
  if (s < 86400) return `${(s / 3600).toFixed(0)} hours`;
  if (s < 31536000) return `${(s / 86400).toFixed(0)} days`;
  const years = s / 31536000;
  if (years > 1e9) return `${(years / 1e9).toExponential(1)} billion years`;
  if (years > 1e6) return `${(years / 1e6).toFixed(1)} million years`;
  return `${years.toFixed(0)} years`;
}

export function PasswordGenerator() {
  const [opts, setOpts] = useState<Options>({
    length: 18,
    lower: true,
    upper: true,
    numbers: true,
    symbols: true,
    avoidAmbiguous: true,
  });
  const [password, setPassword] = useState("");
  const [history, setHistory] = useState<string[]>([]);
  const [confetti, setConfetti] = useState(false);

  const roll = useCallback(
    (celebrate = false) => {
      const pw = generate(opts);
      setPassword(pw);
      setHistory((h) => [pw, ...h].slice(0, 5));
      if (celebrate) {
        setConfetti(true);
        window.setTimeout(() => setConfetti(false), 4200);
      }
    },
    [opts],
  );

  useEffect(() => {
    roll();
  }, [roll]);

  const strength = password ? strengthOf(password, opts) : null;
  const strengthPct = strength ? Math.min((strength.entropy / 128) * 100, 100) : 0;

  const copy = async (value: string) => {
    try {
      await navigator.clipboard.writeText(value);
      toast.success("Password copied");
    } catch {
      toast.error("Could not copy");
    }
  };

  const toggles: [keyof Options, string][] = [
    ["lower", "Lowercase (a–z)"],
    ["upper", "Uppercase (A–Z)"],
    ["numbers", "Numbers (0–9)"],
    ["symbols", "Symbols (!@#$)"],
    ["avoidAmbiguous", "Avoid look-alike characters"],
  ];

  return (
    <>
      {confetti && <Confetti />}
      <div className="grid gap-8 lg:grid-cols-[1fr_0.9fr]">
        <Panel title="Customise your password" badge="Generated locally with secure randomness">
          <Field label={`Length — ${opts.length} characters`} htmlFor="pw-len">
            <input
              id="pw-len"
              type="range"
              min="6"
              max="64"
              value={opts.length}
              onChange={(e) => setOpts({ ...opts, length: Number(e.target.value) })}
              className="w-full accent-[var(--primary)]"
            />
          </Field>
          <div className="space-y-3">
            {toggles.map(([key, label]) => (
              <button
                key={key}
                onClick={() => setOpts({ ...opts, [key]: !opts[key] })}
                className="flex w-full items-center justify-between rounded-2xl border border-glass-border bg-surface px-5 py-3.5 text-left text-sm transition-transform hover:scale-[1.01]"
              >
                <span>{label}</span>
                <span
                  className={`relative h-6 w-11 rounded-full transition-colors ${
                    opts[key] ? "gradient-brand" : "bg-muted"
                  }`}
                >
                  <span
                    className={`absolute top-0.5 h-5 w-5 rounded-full bg-background transition-all ${
                      opts[key] ? "left-[22px]" : "left-0.5"
                    }`}
                  />
                </span>
              </button>
            ))}
          </div>
          <PrimaryButton onClick={() => roll(true)} Icon={KeyRound}>
            Generate new password
          </PrimaryButton>
        </Panel>

        <div className="space-y-4">
          <div className="glass animate-rise rounded-3xl p-7">
            <p className="text-sm text-muted-foreground">Your password</p>
            <p className="mt-4 break-all font-mono text-2xl font-semibold">{password}</p>
            <div className="mt-6 flex flex-wrap gap-2">
              <Action onClick={() => copy(password)} Icon={Copy} label="Copy" />
              <Action onClick={() => roll(false)} Icon={RefreshCw} label="Regenerate" />
            </div>
          </div>

          {strength && (
            <div className="glass rounded-3xl p-7">
              <div className="flex items-center justify-between text-sm">
                <span className="inline-flex items-center gap-2 text-muted-foreground">
                  <ShieldCheck className="h-4 w-4 text-accent" /> Strength
                </span>
                <span className="font-semibold">{strength.label}</span>
              </div>
              <div className="mt-4 h-2.5 w-full overflow-hidden rounded-full bg-surface">
                <div
                  className="h-full rounded-full gradient-brand transition-[width] duration-700"
                  style={{ width: `${strengthPct}%` }}
                />
              </div>
              <div className="mt-5 grid gap-4 sm:grid-cols-2">
                <Stat label="Entropy (bits)" value={strength.entropy} decimals={1} />
                <div className="glass hover-lift rounded-2xl p-5">
                  <p className="font-display text-xl font-semibold">
                    {humanTime(strength.seconds)}
                  </p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    To crack at 10 billion guesses/sec
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {history.length > 1 && (
        <div className="mt-14">
          <ResultHeader>
            Recent <span className="gradient-text">passwords</span>
          </ResultHeader>
          <div className="mt-6 grid gap-3">
            {history.slice(1).map((pw, i) => (
              <div
                key={`${pw}-${i}`}
                className="glass flex items-center justify-between gap-4 rounded-2xl px-5 py-4"
              >
                <span className="break-all font-mono text-sm">{pw}</span>
                <button
                  onClick={() => copy(pw)}
                  aria-label="Copy password"
                  className="shrink-0 rounded-xl border border-glass-border p-2.5 transition-transform hover:scale-110"
                >
                  <Copy className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
          <p className="mt-4 text-xs text-muted-foreground">
            Passwords are never stored or transmitted — this list clears when you leave the page.
          </p>
        </div>
      )}
    </>
  );
}
