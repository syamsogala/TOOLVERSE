import { useState } from "react";
import { TrendingUp } from "lucide-react";
import {
  BigCard,
  Confetti,
  Donut,
  Field,
  Panel,
  PrimaryButton,
  ResultHeader,
  ShareActions,
  Stat,
  inputClass,
} from "./kit";

interface SipResult {
  invested: number;
  future: number;
  gains: number;
  years: number;
  growth: { year: number; invested: number; value: number }[];
}

export function SipCalculator() {
  const [mode, setMode] = useState<"sip" | "lumpsum">("sip");
  const [monthly, setMonthly] = useState("10000");
  const [rate, setRate] = useState("12");
  const [years, setYears] = useState("10");
  const [result, setResult] = useState<SipResult | null>(null);
  const [confetti, setConfetti] = useState(false);

  const calculate = () => {
    const amt = parseFloat(monthly);
    const annual = parseFloat(rate);
    const y = parseFloat(years);
    if (!amt || !y) return;

    const growth: SipResult["growth"] = [];
    let invested = 0;
    let future = 0;

    if (mode === "sip") {
      const r = annual / 12 / 100;
      const n = Math.round(y * 12);
      future = r === 0 ? amt * n : amt * ((Math.pow(1 + r, n) - 1) / r) * (1 + r);
      invested = amt * n;
      for (let yr = 1; yr <= Math.ceil(y); yr++) {
        const m = Math.min(yr * 12, n);
        growth.push({
          year: yr,
          invested: amt * m,
          value: r === 0 ? amt * m : amt * ((Math.pow(1 + r, m) - 1) / r) * (1 + r),
        });
      }
    } else {
      invested = amt;
      future = amt * Math.pow(1 + annual / 100, y);
      for (let yr = 1; yr <= Math.ceil(y); yr++) {
        growth.push({ year: yr, invested: amt, value: amt * Math.pow(1 + annual / 100, yr) });
      }
    }

    setResult({ invested, future, gains: future - invested, years: y, growth });
    setConfetti(true);
    window.setTimeout(() => setConfetti(false), 4200);
  };

  const maxValue = result ? Math.max(...result.growth.map((g) => g.value)) : 1;

  return (
    <>
      {confetti && <Confetti />}
      <div className="grid gap-8 lg:grid-cols-[1fr_0.9fr]">
        <Panel title="Investment details">
          <div className="glass inline-flex rounded-2xl p-1">
            {(["sip", "lumpsum"] as const).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`rounded-xl px-5 py-2 text-sm font-medium capitalize transition-all ${
                  mode === m ? "gradient-brand text-primary-foreground" : "text-muted-foreground"
                }`}
              >
                {m === "sip" ? "Monthly SIP" : "Lumpsum"}
              </button>
            ))}
          </div>
          <Field
            label={mode === "sip" ? "Monthly investment (₹)" : "One-time investment (₹)"}
            htmlFor="sip-a"
          >
            <input
              id="sip-a"
              type="number"
              inputMode="decimal"
              value={monthly}
              onChange={(e) => setMonthly(e.target.value)}
              className={inputClass}
            />
          </Field>
          <Field label={`Expected return — ${rate}% p.a.`} htmlFor="sip-r">
            <input
              id="sip-r"
              type="range"
              min="1"
              max="30"
              step="0.5"
              value={rate}
              onChange={(e) => setRate(e.target.value)}
              className="w-full accent-[var(--primary)]"
            />
          </Field>
          <Field label={`Time period — ${years} years`} htmlFor="sip-y">
            <input
              id="sip-y"
              type="range"
              min="1"
              max="40"
              step="1"
              value={years}
              onChange={(e) => setYears(e.target.value)}
              className="w-full accent-[var(--primary)]"
            />
          </Field>
          <PrimaryButton onClick={calculate} Icon={TrendingUp}>
            Project my wealth
          </PrimaryButton>
        </Panel>

        <div className="glass rounded-3xl p-7">
          <h3 className="font-display text-lg font-semibold">The power of compounding</h3>
          <p className="mt-3 text-sm text-muted-foreground">
            SIP returns are estimated with monthly compounding. Returns are illustrative — markets
            do not deliver a fixed rate every year.
          </p>
          <div className="mt-5 rounded-2xl border border-glass-border p-5 font-mono text-sm">
            FV = P × ((1+r)ⁿ − 1) / r × (1+r)
          </div>
          <ul className="mt-5 space-y-2 text-sm text-muted-foreground">
            <li>P — monthly investment</li>
            <li>r — monthly rate of return</li>
            <li>n — number of instalments</li>
          </ul>
        </div>
      </div>

      {result && (
        <div className="mt-14">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <ResultHeader>
              Your <span className="gradient-text">wealth projection</span>
            </ResultHeader>
            <ShareActions
              title="My SIP projection — ToolVerse"
              text={`₹${Math.round(result.invested).toLocaleString()} invested could grow to ₹${Math.round(result.future).toLocaleString()} in ${result.years} years — projected on ToolVerse.`}
            />
          </div>

          <div className="mt-6 grid gap-4 sm:grid-cols-3">
            <BigCard label="Future value" value={result.future} prefix="₹" />
            <Stat label="Total invested" value={result.invested} prefix="₹" />
            <Stat label="Estimated gains" value={result.gains} prefix="₹" />
          </div>

          <div className="mt-4 grid gap-4 lg:grid-cols-[0.9fr_1.1fr]">
            <Donut
              segments={[
                { label: "Invested", value: result.invested, color: "var(--primary)" },
                { label: "Returns", value: result.gains, color: "var(--secondary)" },
              ]}
            />
            <div className="glass rounded-3xl p-6">
              <p className="text-sm text-muted-foreground">Year-by-year growth</p>
              <div className="mt-6 flex h-48 items-end gap-1.5 overflow-x-auto">
                {result.growth.map((g) => (
                  <div
                    key={g.year}
                    className="flex min-w-[14px] flex-1 flex-col justify-end"
                    title={`Year ${g.year}: ₹${Math.round(g.value).toLocaleString()}`}
                  >
                    <div
                      className="rounded-t-md gradient-brand transition-[height] duration-700 ease-out"
                      style={{ height: `${(g.value / maxValue) * 100}%` }}
                    />
                    <div
                      className="rounded-b-md bg-surface"
                      style={{ height: `${(g.invested / maxValue) * 6}%` }}
                    />
                  </div>
                ))}
              </div>
              <p className="mt-3 text-xs text-muted-foreground">
                Year 1 → Year {Math.ceil(result.years)}
              </p>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
