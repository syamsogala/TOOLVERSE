import { useState } from "react";
import { HeartPulse } from "lucide-react";
import {
  Bar,
  BigCard,
  Confetti,
  Fact,
  Field,
  Panel,
  PrimaryButton,
  ResultHeader,
  ShareActions,
  Stat,
  inputClass,
} from "./kit";

type Unit = "metric" | "imperial";

interface BmiResult {
  bmi: number;
  category: string;
  minWeight: number;
  maxWeight: number;
  idealWeight: number;
  toHealthy: number;
  meters: number;
  kg: number;
}

function categoryFor(bmi: number) {
  if (bmi < 18.5) return "Underweight";
  if (bmi < 25) return "Healthy weight";
  if (bmi < 30) return "Overweight";
  if (bmi < 35) return "Obese (Class I)";
  if (bmi < 40) return "Obese (Class II)";
  return "Obese (Class III)";
}

export function BmiCalculator() {
  const [unit, setUnit] = useState<Unit>("metric");
  const [height, setHeight] = useState("170");
  const [weight, setWeight] = useState("68");
  const [result, setResult] = useState<BmiResult | null>(null);
  const [confetti, setConfetti] = useState(false);

  const calculate = () => {
    const h = parseFloat(height);
    const w = parseFloat(weight);
    if (!h || !w || h <= 0 || w <= 0) return;
    const meters = unit === "metric" ? h / 100 : h * 0.0254;
    const kg = unit === "metric" ? w : w * 0.453592;
    const bmi = kg / (meters * meters);
    const minWeight = 18.5 * meters * meters;
    const maxWeight = 24.9 * meters * meters;
    const idealWeight = 22 * meters * meters;
    const toHealthy = kg < minWeight ? minWeight - kg : kg > maxWeight ? kg - maxWeight : 0;
    setResult({
      bmi,
      category: categoryFor(bmi),
      minWeight,
      maxWeight,
      idealWeight,
      toHealthy,
      meters,
      kg,
    });
    setConfetti(true);
    window.setTimeout(() => setConfetti(false), 4200);
  };

  return (
    <>
      {confetti && <Confetti />}
      <div className="grid gap-8 lg:grid-cols-[1fr_0.9fr]">
        <Panel title="Enter your body measurements">
          <div className="glass inline-flex rounded-2xl p-1">
            {(["metric", "imperial"] as Unit[]).map((u) => (
              <button
                key={u}
                onClick={() => setUnit(u)}
                className={`rounded-xl px-5 py-2 text-sm font-medium capitalize transition-all ${
                  unit === u ? "gradient-brand text-primary-foreground" : "text-muted-foreground"
                }`}
              >
                {u}
              </button>
            ))}
          </div>
          <Field label={unit === "metric" ? "Height (cm)" : "Height (inches)"} htmlFor="bmi-h">
            <input
              id="bmi-h"
              type="number"
              inputMode="decimal"
              value={height}
              onChange={(e) => setHeight(e.target.value)}
              className={inputClass}
            />
          </Field>
          <Field label={unit === "metric" ? "Weight (kg)" : "Weight (lb)"} htmlFor="bmi-w">
            <input
              id="bmi-w"
              type="number"
              inputMode="decimal"
              value={weight}
              onChange={(e) => setWeight(e.target.value)}
              className={inputClass}
            />
          </Field>
          <PrimaryButton onClick={calculate} Icon={HeartPulse}>
            Calculate my BMI
          </PrimaryButton>
          <p className="text-xs text-muted-foreground">
            BMI is a screening indicator, not a diagnosis. Everything is computed on your device.
          </p>
        </Panel>

        <div className="glass rounded-3xl p-7">
          <h3 className="font-display text-lg font-semibold">BMI reference chart</h3>
          <ul className="mt-5 space-y-3 text-sm">
            {[
              ["Underweight", "Below 18.5"],
              ["Healthy weight", "18.5 – 24.9"],
              ["Overweight", "25.0 – 29.9"],
              ["Obese Class I", "30.0 – 34.9"],
              ["Obese Class II", "35.0 – 39.9"],
              ["Obese Class III", "40.0 and above"],
            ].map(([name = "", range = ""]) => (
              <li
                key={name}
                className={`flex items-center justify-between rounded-xl border border-glass-border px-4 py-3 transition-colors ${
                  result?.category.startsWith(name.split(" ")[0] ?? "") ? "bg-primary/15" : ""
                }`}
              >
                <span>{name}</span>
                <span className="text-muted-foreground">{range}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {result && (
        <div className="mt-14 scroll-mt-24">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <ResultHeader>
              Your <span className="gradient-text">BMI report</span>
            </ResultHeader>
            <ShareActions
              title="My BMI — ToolVerse"
              text={`My BMI is ${result.bmi.toFixed(1)} (${result.category}) — calculated on ToolVerse.`}
            />
          </div>

          <div className="mt-6 grid gap-4 sm:grid-cols-3">
            <BigCard label="Body Mass Index" value={result.bmi} decimals={1} />
            <div className="glass hover-lift rounded-3xl p-7">
              <p className="font-display text-3xl font-bold">{result.category}</p>
              <p className="mt-1 text-sm text-muted-foreground">Category</p>
            </div>
            <Stat
              label="Ideal weight (BMI 22)"
              value={result.idealWeight}
              decimals={1}
              suffix=" kg"
            />
          </div>

          <div className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Stat label="Healthy range from" value={result.minWeight} decimals={1} suffix=" kg" />
            <Stat label="Healthy range to" value={result.maxWeight} decimals={1} suffix=" kg" />
            <Stat label="Your weight" value={result.kg} decimals={1} suffix=" kg" />
            <Stat
              label="To reach healthy range"
              value={result.toHealthy}
              decimals={1}
              suffix=" kg"
            />
          </div>

          <div className="mt-4 grid gap-4 lg:grid-cols-3">
            <Bar
              label="Where you sit on the BMI scale (10–40)"
              value={((result.bmi - 10) / 30) * 100}
              caption={result.bmi.toFixed(1)}
            />
            <Fact label="Height used" value={`${result.meters.toFixed(2)} m`} />
            <Fact
              label="Status"
              value={result.toHealthy === 0 ? "In healthy range" : "Outside healthy range"}
            />
          </div>
        </div>
      )}
    </>
  );
}
