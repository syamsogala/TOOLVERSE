import { useState } from "react";
import { Percent } from "lucide-react";
import {
  BigCard,
  Confetti,
  Field,
  Panel,
  PrimaryButton,
  ResultHeader,
  ShareActions,
  Stat,
  inputClass,
} from "./kit";

type Mode = "of" | "isWhat" | "change";

const MODES: { id: Mode; label: string }[] = [
  { id: "of", label: "X% of Y" },
  { id: "isWhat", label: "X is what % of Y" },
  { id: "change", label: "Increase / decrease" },
];

export function PercentageCalculator() {
  const [mode, setMode] = useState<Mode>("of");
  const [a, setA] = useState("15");
  const [b, setB] = useState("2400");
  const [result, setResult] = useState<{
    headline: number;
    suffix: string;
    label: string;
    extras: { label: string; value: number; decimals?: number; suffix?: string }[];
    text: string;
  } | null>(null);
  const [confetti, setConfetti] = useState(false);

  const calculate = () => {
    const x = parseFloat(a);
    const y = parseFloat(b);
    if (Number.isNaN(x) || Number.isNaN(y)) return;

    if (mode === "of") {
      const v = (x / 100) * y;
      setResult({
        headline: v,
        suffix: "",
        label: `${x}% of ${y}`,
        extras: [
          { label: "Remaining amount", value: y - v, decimals: 2 },
          { label: "Double the share", value: v * 2, decimals: 2 },
          { label: "Half the share", value: v / 2, decimals: 2 },
          { label: "Whole value", value: y, decimals: 2 },
        ],
        text: `${x}% of ${y} is ${v.toFixed(2)} — calculated on ToolVerse.`,
      });
    } else if (mode === "isWhat") {
      const v = y === 0 ? 0 : (x / y) * 100;
      setResult({
        headline: v,
        suffix: "%",
        label: `${x} as a percentage of ${y}`,
        extras: [
          { label: "Difference", value: y - x, decimals: 2 },
          { label: "Remaining share", value: 100 - v, decimals: 2, suffix: "%" },
          { label: "Ratio", value: y === 0 ? 0 : x / y, decimals: 3 },
          { label: "Per 1000", value: y === 0 ? 0 : (x / y) * 1000, decimals: 1 },
        ],
        text: `${x} is ${v.toFixed(2)}% of ${y} — calculated on ToolVerse.`,
      });
    } else {
      const v = x === 0 ? 0 : ((y - x) / x) * 100;
      setResult({
        headline: v,
        suffix: "%",
        label: v >= 0 ? "Percentage increase" : "Percentage decrease",
        extras: [
          { label: "Absolute change", value: y - x, decimals: 2 },
          { label: "From value", value: x, decimals: 2 },
          { label: "To value", value: y, decimals: 2 },
          { label: "Multiplier", value: x === 0 ? 0 : y / x, decimals: 3, suffix: "×" },
        ],
        text: `From ${x} to ${y} is a ${Math.abs(v).toFixed(2)}% ${v >= 0 ? "increase" : "decrease"} — calculated on ToolVerse.`,
      });
    }
    setConfetti(true);
    window.setTimeout(() => setConfetti(false), 4200);
  };

  const labels: Record<Mode, [string, string]> = {
    of: ["Percentage (%)", "Of value"],
    isWhat: ["Value", "Total"],
    change: ["From value", "To value"],
  };

  return (
    <>
      {confetti && <Confetti />}
      <div className="grid gap-8 lg:grid-cols-[1fr_0.9fr]">
        <Panel title="Choose a percentage problem">
          <div className="glass flex flex-wrap gap-1 rounded-2xl p-1">
            {MODES.map((m) => (
              <button
                key={m.id}
                onClick={() => setMode(m.id)}
                className={`rounded-xl px-4 py-2 text-sm font-medium transition-all ${
                  mode === m.id ? "gradient-brand text-primary-foreground" : "text-muted-foreground"
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>
          <Field label={labels[mode][0]} htmlFor="pct-a">
            <input
              id="pct-a"
              type="number"
              inputMode="decimal"
              value={a}
              onChange={(e) => setA(e.target.value)}
              className={inputClass}
            />
          </Field>
          <Field label={labels[mode][1]} htmlFor="pct-b">
            <input
              id="pct-b"
              type="number"
              inputMode="decimal"
              value={b}
              onChange={(e) => setB(e.target.value)}
              className={inputClass}
            />
          </Field>
          <PrimaryButton onClick={calculate} Icon={Percent}>
            Calculate percentage
          </PrimaryButton>
        </Panel>

        <div className="glass rounded-3xl p-7">
          <h3 className="font-display text-lg font-semibold">Quick formulas</h3>
          <ul className="mt-5 space-y-3 text-sm">
            {[
              ["X% of Y", "(X ÷ 100) × Y"],
              ["X is what % of Y", "(X ÷ Y) × 100"],
              ["Change from A to B", "((B − A) ÷ A) × 100"],
              ["Reverse percentage", "Total ÷ (1 + P/100)"],
            ].map(([name, formula]) => (
              <li
                key={name}
                className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-glass-border px-4 py-3"
              >
                <span>{name}</span>
                <span className="font-mono text-muted-foreground">{formula}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {result && (
        <div className="mt-14">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <ResultHeader>
              Your <span className="gradient-text">answer</span>
            </ResultHeader>
            <ShareActions title="Percentage result — ToolVerse" text={result.text} />
          </div>

          <div className="mt-6 grid gap-4 sm:grid-cols-3">
            <div className="sm:col-span-1">
              <BigCard
                label={result.label}
                value={result.headline}
                decimals={2}
                suffix={result.suffix}
              />
            </div>
            {result.extras.slice(0, 2).map((e) => (
              <Stat
                key={e.label}
                label={e.label}
                value={e.value}
                decimals={e.decimals ?? 2}
                suffix={e.suffix}
              />
            ))}
          </div>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            {result.extras.slice(2).map((e) => (
              <Stat
                key={e.label}
                label={e.label}
                value={e.value}
                decimals={e.decimals ?? 2}
                suffix={e.suffix}
              />
            ))}
          </div>
        </div>
      )}
    </>
  );
}
