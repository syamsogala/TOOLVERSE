import { useState } from "react";
import { Landmark } from "lucide-react";
import {
  BigCard,
  Confetti,
  Donut,
  Field,
  Panel,
  PrimaryButton,
  ResultHeader,
  ShareActions,
  Stat,
  inputClass,
} from "./kit";

interface EmiResult {
  emi: number;
  principal: number;
  totalInterest: number;
  totalPayment: number;
  months: number;
  schedule: { year: number; principal: number; interest: number; balance: number }[];
}

export function EmiCalculator() {
  const [amount, setAmount] = useState("1000000");
  const [rate, setRate] = useState("8.5");
  const [years, setYears] = useState("15");
  const [result, setResult] = useState<EmiResult | null>(null);
  const [confetti, setConfetti] = useState(false);

  const calculate = () => {
    const p = parseFloat(amount);
    const annual = parseFloat(rate);
    const y = parseFloat(years);
    if (!p || !y || annual < 0) return;
    const n = Math.round(y * 12);
    const r = annual / 12 / 100;
    const emi = r === 0 ? p / n : (p * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    const totalPayment = emi * n;

    let balance = p;
    const schedule: EmiResult["schedule"] = [];
    for (let year = 1; year <= Math.ceil(n / 12); year++) {
      let yp = 0;
      let yi = 0;
      for (let m = 0; m < 12 && (year - 1) * 12 + m < n; m++) {
        const interest = balance * r;
        const principalPart = emi - interest;
        yi += interest;
        yp += principalPart;
        balance -= principalPart;
      }
      schedule.push({ year, principal: yp, interest: yi, balance: Math.max(balance, 0) });
    }

    setResult({
      emi,
      principal: p,
      totalInterest: totalPayment - p,
      totalPayment,
      months: n,
      schedule,
    });
    setConfetti(true);
    window.setTimeout(() => setConfetti(false), 4200);
  };

  return (
    <>
      {confetti && <Confetti />}
      <div className="grid gap-8 lg:grid-cols-[1fr_0.9fr]">
        <Panel title="Loan details">
          <Field label="Loan amount (₹)" htmlFor="emi-a">
            <input
              id="emi-a"
              type="number"
              inputMode="decimal"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className={inputClass}
            />
          </Field>
          <Field label={`Interest rate — ${rate}% p.a.`} htmlFor="emi-r">
            <input
              id="emi-r"
              type="range"
              min="1"
              max="20"
              step="0.1"
              value={rate}
              onChange={(e) => setRate(e.target.value)}
              className="w-full accent-[var(--primary)]"
            />
          </Field>
          <Field label={`Tenure — ${years} years`} htmlFor="emi-y">
            <input
              id="emi-y"
              type="range"
              min="1"
              max="30"
              step="1"
              value={years}
              onChange={(e) => setYears(e.target.value)}
              className="w-full accent-[var(--primary)]"
            />
          </Field>
          <PrimaryButton onClick={calculate} Icon={Landmark}>
            Calculate EMI
          </PrimaryButton>
        </Panel>

        <div className="glass rounded-3xl p-7">
          <h3 className="font-display text-lg font-semibold">How EMI works</h3>
          <p className="mt-3 text-sm text-muted-foreground">
            Your equated monthly instalment stays fixed, but its split changes over time — early
            instalments are mostly interest, later ones mostly principal.
          </p>
          <div className="mt-5 rounded-2xl border border-glass-border p-5 font-mono text-sm">
            EMI = P × r × (1+r)ⁿ / ((1+r)ⁿ − 1)
          </div>
          <ul className="mt-5 space-y-2 text-sm text-muted-foreground">
            <li>P — loan principal</li>
            <li>r — monthly interest rate (annual ÷ 12 ÷ 100)</li>
            <li>n — number of monthly instalments</li>
          </ul>
        </div>
      </div>

      {result && (
        <div className="mt-14">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <ResultHeader>
              Your <span className="gradient-text">repayment plan</span>
            </ResultHeader>
            <ShareActions
              title="My EMI — ToolVerse"
              text={`Monthly EMI ₹${Math.round(result.emi).toLocaleString()} on a ₹${result.principal.toLocaleString()} loan — calculated on ToolVerse.`}
            />
          </div>

          <div className="mt-6 grid gap-4 sm:grid-cols-3">
            <BigCard label="Monthly EMI" value={result.emi} prefix="₹" />
            <Stat label="Total interest" value={result.totalInterest} prefix="₹" />
            <Stat label="Total payment" value={result.totalPayment} prefix="₹" />
          </div>

          <div className="mt-4 grid gap-4 lg:grid-cols-[0.9fr_1.1fr]">
            <Donut
              segments={[
                { label: "Principal", value: result.principal, color: "var(--primary)" },
                { label: "Interest", value: result.totalInterest, color: "var(--secondary)" },
              ]}
            />
            <div className="glass rounded-3xl p-6">
              <p className="text-sm text-muted-foreground">
                Yearly amortisation · {result.months} instalments
              </p>
              <div className="mt-4 max-h-64 overflow-auto pr-1">
                <table className="w-full text-left text-sm">
                  <thead className="text-xs text-muted-foreground">
                    <tr>
                      <th className="pb-2">Year</th>
                      <th className="pb-2">Principal</th>
                      <th className="pb-2">Interest</th>
                      <th className="pb-2">Balance</th>
                    </tr>
                  </thead>
                  <tbody>
                    {result.schedule.map((row) => (
                      <tr key={row.year} className="border-t border-glass-border">
                        <td className="py-2">{row.year}</td>
                        <td className="py-2">₹{Math.round(row.principal).toLocaleString()}</td>
                        <td className="py-2">₹{Math.round(row.interest).toLocaleString()}</td>
                        <td className="py-2">₹{Math.round(row.balance).toLocaleString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
