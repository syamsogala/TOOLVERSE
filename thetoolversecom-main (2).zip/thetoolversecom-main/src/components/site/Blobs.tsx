export function Blobs() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      {/* Aurora field */}
      <div className="absolute -left-48 -top-56 h-[42rem] w-[42rem] rounded-full bg-primary/25 blur-[140px] animate-blob" />
      <div
        className="absolute -right-56 top-10 h-[38rem] w-[38rem] rounded-full bg-secondary/25 blur-[150px] animate-blob"
        style={{ animationDelay: "-7s" }}
      />
      <div
        className="absolute bottom-[-10rem] left-1/3 h-[32rem] w-[32rem] rounded-full bg-accent/14 blur-[150px] animate-blob"
        style={{ animationDelay: "-14s" }}
      />

      {/* Fine grid, faded toward the fold */}
      <div className="absolute inset-0 grid-fade opacity-70" />

      {/* Top halo */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_-15%,color-mix(in_oklab,var(--primary)_20%,transparent),transparent_62%)]" />

      {/* Subtle film grain for depth */}
      <div
        className="absolute inset-0 opacity-[0.035] mix-blend-overlay"
        style={{
          backgroundImage:
            "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='140' height='140'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='3'/%3E%3C/filter%3E%3Crect width='140' height='140' filter='url(%23n)'/%3E%3C/svg%3E\")",
        }}
      />
    </div>
  );
}
