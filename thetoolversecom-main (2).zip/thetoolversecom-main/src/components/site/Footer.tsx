import { Link } from "@tanstack/react-router";
import { Boxes, Github, Twitter, Linkedin, Instagram } from "lucide-react";
import { tools } from "@/data/tools";

export function Footer() {
  return (
    <footer className="mt-24 border-t border-glass-border">
      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-14 lg:grid-cols-4 lg:px-8">
        <div>
          <div className="flex items-center gap-3">
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl gradient-brand text-primary-foreground">
              <Boxes className="h-5 w-5" />
            </span>
            <span className="font-display text-lg font-semibold">
              Tool<span className="gradient-text">Verse</span>
            </span>
          </div>
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-muted-foreground">
            ToolVerse brings every everyday online tool into one beautiful, lightning-fast place —
            free forever, no sign-up, no clutter.
          </p>
          <div className="mt-5 flex gap-2">
            {[
              { Icon: Github, label: "GitHub", href: "https://github.com" },
              { Icon: Twitter, label: "Twitter", href: "https://twitter.com" },
              { Icon: Linkedin, label: "LinkedIn", href: "https://linkedin.com" },
              { Icon: Instagram, label: "Instagram", href: "https://instagram.com" },
            ].map(({ Icon, label, href }) => (
              <a
                key={label}
                href={href}
                aria-label={label}
                target="_blank"
                rel="noreferrer noopener"
                className="grid h-10 w-10 place-items-center rounded-xl border border-glass-border text-muted-foreground transition-all hover:scale-105 hover:text-foreground"
              >
                <Icon className="h-4 w-4" />
              </a>
            ))}
          </div>
        </div>

        <FooterCol title="Quick Links">
          <FLink to="/">Home</FLink>
          <FLink to="/tools">All Tools</FLink>
          <FLink to="/categories">Categories</FLink>
          <FLink to="/about">About</FLink>
          <FLink to="/contact">Contact</FLink>
        </FooterCol>

        <FooterCol title="Popular Tools">
          {tools.slice(0, 5).map((t) =>
            t.available ? (
              <Link
                key={t.slug}
                to="/tools/$slug"
                params={{ slug: t.slug }}
                className="block text-sm text-muted-foreground transition-colors hover:text-foreground"
              >
                {t.name}
              </Link>
            ) : (
              <span key={t.slug} className="block text-sm text-muted-foreground/70">
                {t.name}
              </span>
            ),
          )}
        </FooterCol>

        <FooterCol title="Legal">
          <FLink to="/privacy">Privacy Policy</FLink>
          <FLink to="/terms">Terms of Use</FLink>
          <a
            href="https://github.com"
            target="_blank"
            rel="noreferrer noopener"
            className="block text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            GitHub
          </a>
        </FooterCol>
      </div>

      <div className="border-t border-glass-border px-5 py-6 text-center text-xs text-muted-foreground lg:px-8">
        © {new Date().getFullYear()} ToolVerse. One Place. Infinite Tools.
      </div>
    </footer>
  );
}

function FooterCol({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 className="text-sm font-semibold uppercase tracking-wider">{title}</h3>
      <div className="mt-4 space-y-2.5">{children}</div>
    </div>
  );
}

function FLink({ to, children }: { to: string; children: React.ReactNode }) {
  return (
    <Link
      to={to}
      className="block text-sm text-muted-foreground transition-colors hover:text-foreground"
    >
      {children}
    </Link>
  );
}
