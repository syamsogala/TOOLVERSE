import { Link } from "@tanstack/react-router";
import { ArrowRight, Sparkles } from "lucide-react";
import type { Tool } from "@/data/tools";

export function ToolCard({ tool }: { tool: Tool }) {
  const Icon = tool.icon;

  const body = (
    <article className="group glass-strong hover-lift ring-gradient sheen relative flex h-full flex-col overflow-hidden rounded-[1.75rem] p-6">
      <div className="pointer-events-none absolute inset-0 opacity-0 transition-opacity duration-500 group-hover:opacity-100 bg-[var(--gradient-soft)]" />
      <div className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full bg-primary/25 blur-3xl opacity-0 transition-opacity duration-500 group-hover:opacity-100" />

      <div className="relative flex items-center justify-between gap-3">
        <span className="relative grid h-14 w-14 shrink-0 place-items-center rounded-2xl gradient-brand text-primary-foreground shadow-[var(--shadow-glow)] transition-transform duration-500 group-hover:-rotate-6 group-hover:scale-105">
          <Icon className="h-7 w-7" strokeWidth={1.6} />
        </span>
        <span className="rounded-full border border-glass-border bg-surface px-3 py-1 text-[11px] font-medium uppercase tracking-[0.14em] text-muted-foreground">
          {tool.category}
        </span>
      </div>

      <h3 className="relative mt-5 font-display text-lg font-semibold tracking-[-0.01em]">
        {tool.name}
      </h3>
      <p className="relative mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">
        {tool.description}
      </p>

      <span
        className={`relative mt-6 inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition-all duration-300 group-hover:gap-3 ${
          tool.available
            ? "gradient-brand text-primary-foreground"
            : "border border-glass-border text-muted-foreground"
        }`}
      >
        {tool.available ? (
          <>
            Open tool <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5" />
          </>
        ) : (
          <>
            Coming soon <Sparkles className="h-4 w-4" />
          </>
        )}
      </span>
    </article>
  );

  if (!tool.available) return body;

  return (
    <Link
      to="/tools/$slug"
      params={{ slug: tool.slug }}
      className="block h-full rounded-[1.75rem] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background"
    >
      {body}
    </Link>
  );
}
